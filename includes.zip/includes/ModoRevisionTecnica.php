<?php
// includes/ModoRevisionTecnica.php

class ModoRevisionTecnica {
    private $textoCompleto;
    private $vulnerabilidades = [];
    private $areasMetodologicas = [];
    private $preguntas = [];
    
    public function __construct($texto) {
        $this->textoCompleto = $texto;
    }
    
    public function generarAnalisis() {
        $this->analizarVulnerabilidades();
        $this->analizarAreasMetodologicas();
        $this->generarCuestionario();
        
        $respuesta = $this->generarTablaVulnerabilidades();
        $respuesta .= $this->generarMatrizAreas();
        $respuesta .= $this->generarCuestionarioTecnico();
        $respuesta .= $this->generarNotaResponsabilidad();
        
        return $respuesta;
    }
    
    private function analizarVulnerabilidades() {
        $paginas = explode("=== PÁGINA ", $this->textoCompleto);
        
        foreach ($paginas as $index => $pagina) {
            if ($index == 0) continue;
            $numPagina = $index;
            $this->analizarVulnerabilidadesEnPagina($pagina, $numPagina);
        }
    }
    
    private function analizarVulnerabilidadesEnPagina($texto, $pagina) {
        $this->analizarTerminologiaValorativa($texto, $pagina);
        $this->analizarAtribucionDerechos($texto, $pagina);
        $this->analizarAdelantoConclusiones($texto, $pagina);
        $this->analizarMarcoGeodesico($texto, $pagina);
        $this->analizarSistemaReferencia($texto, $pagina);
        $this->analizarCoherenciaMetodologica($texto, $pagina);
        $this->analizarInstrumentacion($texto, $pagina);
        $this->analizarJustificacionTecnica($texto, $pagina);
        $this->analizarCadenaLogica($texto, $pagina);
        $this->analizarSupuestosImplicitos($texto, $pagina);
        $this->analizarCoherenciaGrafica($texto, $pagina);
        $this->analizarNormativaTecnica($texto, $pagina);
    }
    
    private function analizarTerminologiaValorativa($texto, $pagina) {
        $terminosValorativos = [
            '/\b(?:correcto|incorrecto|erróneo|acertado|desacertado)\b/i',
            '/\b(?:adecuado|inadecuado|apropiado|inapropiado)\b/i',
            '/\b(?:preciso|impreciso|exacto|inexacto)\b/i',
            '/\b(?:bueno|malo|mejor|peor)\b/i'
        ];
        
        foreach ($terminosValorativos as $patron) {
            if (preg_match_all($patron, $texto, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $this->agregarVulnerabilidad(
                        "Terminología",
                        "Se observa uso de terminología con posible carga valorativa",
                        $pagina,
                        "Lenguaje valorativo",
                        "MEDIO"
                    );
                    break; // Solo una vez por página para esta categoría
                }
            }
        }
    }
    
    private function analizarAtribucionDerechos($texto, $pagina) {
        $patronesDerechos = [
            '/\b(?:propietario|dueño|titular|poseedor)\s+(?:legítimo|originario|verdadero|real)\b/i',
            '/\b(?:derecho\s+(?:de|a|sobre)|propiedad\s+(?:de|sobre)|titularidad\s+(?:de))\b/i'
        ];
        
        foreach ($patronesDerechos as $patron) {
            if (preg_match_all($patron, $texto, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $this->agregarVulnerabilidad(
                        "Atribución de derechos",
                        "Expresión que implica atribución de derechos",
                        $pagina,
                        "Inferencia jurídica",
                        "ALTO"
                    );
                    break; // Solo una vez por página para esta categoría
                }
            }
        }
    }
    
    private function analizarAdelantoConclusiones($texto, $pagina) {
        $patronesAdelanto = [
            '/\b(?:por lo tanto|en consecuencia|así pues|concluyo)\b.*?(?:antes de|previo a|sin\s+haber)\b/i',
            '/\b(?:queda demostrado|ha quedado acreditado|resulta evidente)\b.*?(?:sin\s+embargo)\b.{0,100}/i'
        ];
        
        foreach ($patronesAdelanto as $patron) {
            if (preg_match_all($patron, $texto, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $this->agregarVulnerabilidad(
                        "Estructura argumental",
                        "Posible adelanto de conclusiones",
                        $pagina,
                        "Adelanto de conclusiones",
                        "ALTO"
                    );
                    break; // Solo una vez por página para esta categoría
                }
            }
        }
    }
    
    private function analizarMarcoGeodesico($texto, $pagina) {
        $marcosGeodesicos = ['ITRF', 'WGS84', 'NAD27', 'NAD83', 'ED50', 'SIRGAS'];
        $mencionados = [];
        
        foreach ($marcosGeodesicos as $marco) {
            if (stripos($texto, $marco) !== false) {
                $mencionados[] = $marco;
            }
        }
        
        if (empty($mencionados)) {
            $this->agregarVulnerabilidad(
                "Marco geodésico",
                "No se identifica referencia al marco geodésico utilizado",
                $pagina,
                "Omisión metodológica",
                "ALTO"
            );
        }
    }
    
    private function analizarSistemaReferencia($texto, $pagina) {
        $sistemasReferencia = ['UTM', 'GEOGRÁFICAS', 'GEOCÉNTRICAS', 'LOCAL'];
        $encontrado = false;
        
        foreach ($sistemasReferencia as $sistema) {
            if (stripos($texto, $sistema) !== false) {
                $encontrado = true;
                break;
            }
        }
        
        if (!$encontrado) {
            $this->agregarVulnerabilidad(
                "Sistema de referencia",
                "No se identifica declaración del sistema de referencia",
                $pagina,
                "Omisión metodológica",
                "ALTO"
            );
        }
    }
    
    private function analizarCoherenciaMetodologica($texto, $pagina) {
        $tieneMetodologiaConceptual = preg_match('/\b(?:metodología|método|procedimiento)\s+(?:conceptual|teórica)\b/i', $texto);
        $tieneMetodologiaMetrologica = preg_match('/\b(?:medición|levantamiento|observación)\s+(?:de|de\s+coordenadas)\b/i', $texto);
        
        if ($tieneMetodologiaConceptual && !$tieneMetodologiaMetrologica) {
            $this->agregarVulnerabilidad(
                "Coherencia metodológica",
                "Metodología conceptual sin desarrollo metrológico",
                $pagina,
                "Inconsistencia metodológica",
                "MEDIO"
            );
        }
    }
    
    private function analizarInstrumentacion($texto, $pagina) {
        $instrumentos = [
            'GPS' => ['gps', 'gnss'],
            'Estación total' => ['estación total', 'teodolito'],
            'Nivel' => ['nivel', 'nivelación'],
            'Drone' => ['drone', 'uav']
        ];
        
        $encontrados = [];
        foreach ($instrumentos as $tipo => $keywords) {
            foreach ($keywords as $keyword) {
                if (stripos($texto, $keyword) !== false) {
                    $encontrados[] = $tipo;
                    break;
                }
            }
        }
        
        if (empty($encontrados)) {
            $this->agregarVulnerabilidad(
                "Instrumentación",
                "No se identifica la instrumentación utilizada",
                $pagina,
                "Omisión técnica",
                "ALTO"
            );
        }
    }
    
    private function analizarJustificacionTecnica($texto, $pagina) {
        if (preg_match('/\b(?:se utilizó|se empleó|se usó)\s+(?:un|el|la)\s+([^\.]+)/i', $texto, $matches)) {
            $contexto = substr($texto, max(0, strpos($texto, $matches[0]) - 200), 400);
            if (!preg_match('/(?:porque|debido a|ya que|justificación)/i', $contexto)) {
                $this->agregarVulnerabilidad(
                    "Justificación técnica",
                    "No se desarrolla justificación técnica del equipo utilizado",
                    $pagina,
                    "Justificación insuficiente",
                    "MEDIO"
                );
            }
        }
    }
    
    private function analizarCadenaLogica($texto, $pagina) {
        $tieneDatos = preg_match('/\b(?:dato|medición|observación|lectura|coordenada)\b/i', $texto);
        $tieneAnalisis = preg_match('/\b(?:análisis|cálculo|procesamiento|determinación)\b/i', $texto);
        $tieneConclusiones = preg_match('/\b(?:conclusión|resultado|hallazgo)\b/i', $texto);
        
        $faltantes = [];
        if (!$tieneDatos) $faltantes[] = "datos";
        if (!$tieneAnalisis) $faltantes[] = "análisis";
        if (!$tieneConclusiones) $faltantes[] = "conclusiones";
        
        if (!empty($faltantes) && count($faltantes) < 3) {
            $this->agregarVulnerabilidad(
                "Cadena lógica",
                "Cadena lógica incompleta",
                $pagina,
                "Estructura incompleta",
                "ALTO"
            );
        }
    }
    
    private function analizarSupuestosImplicitos($texto, $pagina) {
        $patronesSupuestos = [
            '/\b(?:asumiendo|suponiendo|considerando que|dado que)\b/i',
            '/\b(?:en condiciones normales|bajo condiciones ideales)\b/i'
        ];
        
        foreach ($patronesSupuestos as $patron) {
            if (preg_match_all($patron, $texto, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) {
                    $this->agregarVulnerabilidad(
                        "Supuestos implícitos",
                        "Supuesto no declarado explícitamente",
                        $pagina,
                        "Supuesto implícito",
                        "MEDIO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarCoherenciaGrafica($texto, $pagina) {
        if (preg_match_all('/\b(?:plano|figura|tabla|cuadro)\s+(\d+)\b/i', $texto, $matches)) {
            foreach ($matches[0] as $ref) {
                $contexto = substr($texto, max(0, strpos($texto, $ref) - 100), 300);
                if (!preg_match('/(?:muestra|presenta|indica|contiene|se aprecia|se observa)/i', $contexto)) {
                    $this->agregarVulnerabilidad(
                        "Coherencia gráfica",
                        "Referencia sin descripción suficiente",
                        $pagina,
                        "Inconsistencia texto-gráfico",
                        "BAJO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarNormativaTecnica($texto, $pagina) {
        if (preg_match('/\b(?:conforme a|de acuerdo con|según|basado en)\s+(?:normativa|normas|regulaciones)\b/i', $texto) && 
            !preg_match('/\b(?:NMX|ISO|NOM|INEGI)\b/i', $texto)) {
            $this->agregarVulnerabilidad(
                "Normativa técnica",
                "Se declara aplicación de normativa no especificada",
                $pagina,
                "Omisión normativa",
                "MEDIO"
            );
        }
    }
    
    private function analizarAreasMetodologicas() {
        $areas = [
            "Marco geodésico" => "No se explicita el marco geodésico de referencia",
            "Sistema de coordenadas" => "No se declara el sistema de coordenadas utilizado",
            "Datum vertical" => "No se especifica el datum vertical",
            "Precisión instrumental" => "No se declara la precisión de los instrumentos",
            "Método de levantamiento" => "No se describe el método de levantamiento",
            "Procesamiento de datos" => "No se explica el procesamiento de datos",
            "Tolerancias aplicadas" => "No se mencionan las tolerancias",
            "Control de calidad" => "No se describe el control de calidad",
            "Fecha de levantamiento" => "No se indica la fecha del levantamiento"
        ];
        
        foreach ($areas as $area => $descripcionBase) {
            if (!$this->verificarAreaMetodologica($area)) {
                $this->areasMetodologicas[] = [
                    'area' => $area,
                    'descripcion' => $descripcionBase
                ];
            }
        }
    }
    
    private function verificarAreaMetodologica($area) {
        $keywords = [
            "Marco geodésico" => ['itrf', 'wgs84', 'nad27', 'nad83'],
            "Sistema de coordenadas" => ['utm', 'coordenadas', 'geográficas'],
            "Datum vertical" => ['datum vertical', 'nivel medio del mar', 'altitud'],
            "Precisión instrumental" => ['precisión', 'exactitud', 'tolerancia'],
            "Método de levantamiento" => ['método', 'procedimiento', 'técnica de levantamiento'],
            "Procesamiento de datos" => ['procesamiento', 'cálculo', 'ajuste'],
            "Tolerancias aplicadas" => ['tolerancia', 'margen de error'],
            "Control de calidad" => ['control de calidad', 'verificación', 'validación'],
            "Fecha de levantamiento" => ['fecha', 'día del levantamiento']
        ];
        
        if (!isset($keywords[$area])) return false;
        
        foreach ($keywords[$area] as $keyword) {
            if (stripos($this->textoCompleto, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    private function generarCuestionario() {
        // Reiniciar preguntas como arrays vacíos
        $this->preguntas = [
            'A' => [], 'B' => [], 'C' => [], 'D' => [], 'E' => [], 'F' => []
        ];
        
        // Usar un array para trackear preguntas ya agregadas
        $preguntasAgregadas = [];
        
        foreach ($this->vulnerabilidades as $vuln) {
            $area = null;
            $pregunta = null;
            
            switch ($vuln['area']) {
                case 'Terminología':
                case 'Atribución de derechos':
                    $area = 'E';
                    $pregunta = "¿En qué apartado se define la terminología técnica utilizada en el dictamen?";
                    break;
                    
                case 'Marco geodésico':
                    $area = 'D';
                    $pregunta = "¿Cuál es el marco geodésico utilizado y su época de referencia?";
                    break;
                    
                case 'Sistema de referencia':
                    $area = 'D';
                    $pregunta = "¿Qué sistema de coordenadas se empleó en el levantamiento?";
                    break;
                    
                case 'Instrumentación':
                    $area = 'C';
                    $pregunta = "¿Cuál es la precisión nominal de los instrumentos utilizados?";
                    break;
                    
                case 'Justificación técnica':
                    $area = 'E';
                    $pregunta = "¿En qué apartado se justifica la idoneidad del equipo empleado?";
                    break;
                    
                case 'Cadena lógica':
                    $area = 'F';
                    $pregunta = "¿Cómo se relacionan los datos presentados con las conclusiones del dictamen?";
                    break;
            }
            
            // Agregar solo si es una pregunta nueva para esta área
            if ($area && $pregunta) {
                $clave = $area . '_' . md5($pregunta);
                if (!in_array($clave, $preguntasAgregadas)) {
                    $this->preguntas[$area][] = $pregunta;
                    $preguntasAgregadas[] = $clave;
                }
            }
        }
        
        // Preguntas por defecto (solo si el área está vacía)
        if (empty($this->preguntas['A'])) {
            $this->preguntas['A'][] = "¿Cuál es el marco conceptual de la metodología empleada?";
        }
        if (empty($this->preguntas['B'])) {
            $this->preguntas['B'][] = "¿Cómo se describe el procedimiento de levantamiento en campo?";
        }
        if (empty($this->preguntas['C'])) {
            $this->preguntas['C'][] = "¿Qué instrumentos se utilizaron y cuál es su estado de calibración?";
        }
        if (empty($this->preguntas['D'])) {
            $this->preguntas['D'][] = "¿En qué apartado se documenta el marco geodésico y sistema de referencia?";
        }
        if (empty($this->preguntas['E'])) {
            $this->preguntas['E'][] = "¿Qué terminología técnica se emplea y cómo se define?";
        }
        if (empty($this->preguntas['F'])) {
            $this->preguntas['F'][] = "¿Cómo se vinculan los datos con las conclusiones presentadas?";
        }
        
        // Eliminar duplicados dentro de cada área (por si acaso)
        foreach ($this->preguntas as $area => $preguntas) {
            $this->preguntas[$area] = array_values(array_unique($preguntas));
        }
    }
    
    private function agregarVulnerabilidad($area, $hallazgo, $pagina, $tipo, $riesgo) {
        $num = count($this->vulnerabilidades) + 1;
        
        $this->vulnerabilidades[] = [
            'num' => $num,
            'area' => $area,
            'hallazgo' => $hallazgo,
            'pagina' => $pagina,
            'tipo' => $tipo,
            'riesgo' => $riesgo,
            'observaciones' => '',
            'atendido' => ''
        ];
    }
    
    private function generarTablaVulnerabilidades() {
        if (empty($this->vulnerabilidades)) {
            return "\n**✅ No se identificaron vulnerabilidades estructurales.**\n\n";
        }
        
        $tabla = "\n**🔍 TABLA DE VULNERABILIDADES ESTRUCTURALES**\n";
        $tabla .= str_repeat("─", 140) . "\n\n";
        $tabla .= "| Nº | Área evaluada | Hallazgo estructural | Página | Tipo de vulnerabilidad | Riesgo | Observaciones | Atendido |\n";
        $tabla .= "|----|---------------|----------------------|--------|------------------------|--------|---------------|----------|\n";
        
        foreach ($this->vulnerabilidades as $vuln) {
            $tabla .= sprintf("| %d | %s | %s | %d | %s | %s | | |\n",
                $vuln['num'],
                $vuln['area'],
                $vuln['hallazgo'],
                $vuln['pagina'],
                $vuln['tipo'],
                $vuln['riesgo']
            );
        }
        
        $tabla .= "\n";
        return $tabla;
    }
    
    private function generarMatrizAreas() {
        if (empty($this->areasMetodologicas)) {
            return "**✅ Todas las áreas metodológicas están explicitadas.**\n\n";
        }
        
        $matriz = "\n**📊 MATRIZ DE ÁREAS METODOLÓGICAS NO EXPLICITADAS**\n";
        $matriz .= str_repeat("─", 140) . "\n\n";
        $matriz .= "| Área | Descripción |\n";
        $matriz .= "|------|-------------|\n";
        
        foreach ($this->areasMetodologicas as $area) {
            $matriz .= "| **{$area['area']}** | {$area['descripcion']} |\n";
        }
        $matriz .= "\n";
        
        return $matriz;
    }
    
    private function generarCuestionarioTecnico() {
        $cuestionario = "\n**❓ CUESTIONARIO TÉCNICO PRELIMINAR PARA AUDIENCIA**\n";
        $cuestionario .= str_repeat("─", 140) . "\n\n";
        
        $areas = [
            'A' => 'Metodología conceptual',
            'B' => 'Metodología metrológica',
            'C' => 'Instrumentación y precisión',
            'D' => 'Marco geodésico y sistema de referencia',
            'E' => 'Terminología utilizada',
            'F' => 'Coherencia lógica y conclusiones'
        ];
        
        foreach ($areas as $letra => $nombre) {
            if (!empty($this->preguntas[$letra])) {
                $cuestionario .= "**{$letra}) {$nombre}**\n";
                foreach ($this->preguntas[$letra] as $pregunta) {
                    $cuestionario .= "   • {$pregunta}\n";
                }
                $cuestionario .= "\n";
            }
        }
        
        return $cuestionario;
    }
    
    private function generarNotaResponsabilidad() {
        $nota = "\n" . str_repeat("═", 140) . "\n";
        $nota .= "**⚖️ NOTA DE RESPONSABILIDAD**\n";
        $nota .= str_repeat("═", 140) . "\n";
        $nota .= "Mextopo es un asistente de inteligencia artificial utilizado como\n";
        $nota .= "herramienta de apoyo. El contenido generado puede contener errores\n";
        $nota .= "u omisiones. La revisión final y la responsabilidad del dictamen\n";
        $nota .= "corresponden exclusivamente al perito firmante.\n";
        $nota .= str_repeat("═", 140) . "\n";
        
        return $nota;
    }
}
?>