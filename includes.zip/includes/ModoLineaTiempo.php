<?php
// includes/ModoLineaTiempo.php

class ModoLineaTiempo {
    private $textoCompleto;
    private $eventos = [];
    
    public function __construct($texto) {
        $this->textoCompleto = $texto;
    }
    
    public function generarAnalisis() {
        $this->extraerEventos();
        $this->ordenarEventos();
        
        $respuesta = $this->generarEncabezado();
        $respuesta .= $this->generarTablaEventos();
        $respuesta .= $this->generarNotaResponsabilidad();
        
        return $respuesta;
    }
    
    private function generarEncabezado() {
        $encabezado = "\n" . str_repeat("═", 140) . "\n";
        $encabezado .= "                     **📅 MODO LÍNEA DE TIEMPO - ANÁLISIS CRONOLÓGICO**\n";
        $encabezado .= str_repeat("═", 140) . "\n\n";
        
        $encabezado .= "| **Resumen** | **Valor** |\n";
        $encabezado .= "|-------------|-----------|\n";
        $encabezado .= "| Documento analizado | " . $this->contarPaginas() . " páginas |\n";
        $encabezado .= "| Eventos identificados | " . count($this->eventos) . " |\n";
        $encabezado .= "| Período cubierto | " . $this->obtenerPeriodo() . " |\n\n";
        
        return $encabezado;
    }
    
    private function generarTablaEventos() {
        if (empty($this->eventos)) {
            return "**⚠️ No se identificaron eventos con fechas en el documento.**\n\n";
        }
        
        $tabla = "**📊 TABLA CRONOLÓGICA ÚNICA**\n";
        $tabla .= str_repeat("─", 140) . "\n\n";
        $tabla .= "| Fecha / periodo | Tipo | Descripción | Qué se pretende acreditar | Ubicación | Fuente declarativa | Naturaleza temporal | Observaciones | Verificable técnicamente | Relación con objeto |\n";
        $tabla .= "|-----------------|------|-------------|---------------------------|-----------|---------------------|---------------------|---------------|--------------------------|---------------------|\n";
        
        foreach ($this->eventos as $evento) {
            $descripcion = str_replace(["\n", "\r"], " ", $evento['descripcion']);
            $descripcion = substr($descripcion, 0, 70) . (strlen($descripcion) > 70 ? '...' : '');
            
            $pretende = str_replace(["\n", "\r"], " ", $evento['pretende']);
            $pretende = substr($pretende, 0, 50) . (strlen($pretende) > 50 ? '...' : '');
            
            $tabla .= sprintf("| %s | %s | %s | %s | %s | %s | %s |  | %s | %s |\n",
                $evento['fecha'],
                $evento['tipo'],
                $descripcion,
                $pretende,
                $evento['ubicacion'],
                $evento['fuente'],
                $evento['naturaleza'],
                $evento['verificable'],
                $evento['relacion']
            );
        }
        
        $tabla .= "\n";
        return $tabla;
    }
    
    private function generarNotaResponsabilidad() {
        $nota = "\n" . str_repeat("═", 140) . "\n";
        $nota .= "**⚖️ NOTA DE RESPONSABILIDAD**\n";
        $nota .= str_repeat("═", 140) . "\n";
        $nota .= "Mextopo es un asistente de inteligencia artificial utilizado como\n";
        $nota .= "herramienta de apoyo. El contenido generado puede contener errores\n";
        $nota .= "u omisiones. La revisión final y la responsabilidad del dictamen\n";
        $nota .= "corresponden exclusivamente al perito firmante.\n";
        $nota .= str_repeat("═", 140) . "\n";
        
        return $nota;
    }
    
    private function contarPaginas() {
        if (empty($this->eventos)) return 0;
        $paginas = array_unique(array_column($this->eventos, 'pagina'));
        return count($paginas);
    }
    
    private function obtenerPeriodo() {
        if (empty($this->eventos)) return "No determinado";
        
        $fechas = array_column($this->eventos, 'fecha_raw');
        $primerFecha = reset($fechas);
        $ultimaFecha = end($fechas);
        
        return $primerFecha . " — " . $ultimaFecha;
    }
    
    private function extraerEventos() {
        $paginas = explode("=== PÁGINA ", $this->textoCompleto);
        
        foreach ($paginas as $index => $pagina) {
            if ($index == 0) continue;
            
            preg_match('/^(\d+)/', $pagina, $matches);
            $numPagina = $matches[1] ?? $index;
            
            $this->buscarFechasEnTexto($pagina, $numPagina);
        }
        
        if (empty($this->eventos)) {
            $this->eventos[] = [
                'fecha' => 'No identificada',
                'fecha_raw' => '',
                'tipo' => 'documento',
                'descripcion' => 'No se encontraron eventos con fechas en el documento',
                'pretende' => 'N/A',
                'ubicacion' => 'Documento completo',
                'fuente' => 'No identificable',
                'naturaleza' => 'No determinada',
                'verificable' => 'No aplica',
                'relacion' => 'Contextual',
                'observaciones' => '',
                'timestamp' => 0,
                'pagina' => 1
            ];
        }
    }
    
    private function buscarFechasEnTexto($texto, $numPagina) {
        $patrones = [
            '/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})/',
            '/(\d{1,2})\s+de\s+([a-zA-Záéíóú]+)\s+de\s+(\d{4})/',
            '/([a-zA-Záéíóú]+)\s+(\d{1,2})[,]?\s+de?\s*(\d{4})/',
            '/(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/',
            '/\b(19\d{2}|20\d{2})\b/',
            '/(\d{4})\s*[–-]\s*(\d{4})/'
        ];
        
        $meses = [
            'enero' => 1, 'febrero' => 2, 'marzo' => 3, 'abril' => 4,
            'mayo' => 5, 'junio' => 6, 'julio' => 7, 'agosto' => 8,
            'septiembre' => 9, 'octubre' => 10, 'noviembre' => 11, 'diciembre' => 12,
            'ene' => 1, 'feb' => 2, 'mar' => 3, 'abr' => 4, 'jun' => 6,
            'jul' => 7, 'ago' => 8, 'sep' => 9, 'oct' => 10, 'nov' => 11, 'dic' => 12
        ];
        
        $lineas = explode("\n", $texto);
        $fechasEncontradas = [];
        
        foreach ($lineas as $linea) {
            if (strlen(trim($linea)) < 10) continue;
            
            foreach ($patrones as $patron) {
                if (preg_match_all($patron, $linea, $matches, PREG_SET_ORDER)) {
                    foreach ($matches as $match) {
                        $fecha = $match[0];
                        
                        $clave = $fecha . "_" . $numPagina;
                        if (in_array($clave, $fechasEncontradas)) {
                            continue;
                        }
                        $fechasEncontradas[] = $clave;
                        
                        $timestamp = $this->convertirFechaATimestamp($match, $meses);
                        
                        $this->eventos[] = [
                            'fecha' => $fecha,
                            'fecha_raw' => $fecha,
                            'tipo' => $this->determinarTipo($linea),
                            'descripcion' => $this->extraerDescripcion($linea, $fecha),
                            'pretende' => $this->determinarPretension($linea),
                            'ubicacion' => "Página " . $numPagina,
                            'fuente' => $this->determinarFuente($linea),
                            'naturaleza' => $this->determinarNaturaleza($fecha),
                            'verificable' => $this->determinarVerificable($linea),
                            'relacion' => $this->determinarRelacion($linea),
                            'observaciones' => '',
                            'timestamp' => $timestamp,
                            'pagina' => $numPagina
                        ];
                        
                        break;
                    }
                }
            }
        }
    }
    
    private function convertirFechaATimestamp($match, $meses) {
        try {
            if (count($match) == 4 && is_numeric($match[1]) && is_numeric($match[2])) {
                $dia = $match[1];
                $mes = $match[2];
                $anio = strlen($match[3]) == 2 ? 2000 + $match[3] : $match[3];
                return strtotime("$anio-$mes-$dia");
            }
            
            if (count($match) == 4 && isset($meses[strtolower($match[2])])) {
                $dia = $match[1];
                $mes = $meses[strtolower($match[2])];
                $anio = $match[3];
                return strtotime("$anio-$mes-$dia");
            }
            
            if (count($match) == 2 && is_numeric($match[1]) && strlen($match[1]) == 4) {
                return strtotime($match[1] . "-01-01");
            }
            
        } catch (Exception $e) {
            return 0;
        }
        
        return 0;
    }
    
    private function determinarTipo($texto) {
        $textoLower = strtolower($texto);
        
        if (preg_match('/documento|escrito|oficio|constancia|contrato|escritura/', $textoLower)) return 'documento';
        if (preg_match('/demanda|contestación|alegatos|prueba|sentencia|juicio/', $textoLower)) return 'acto procesal';
        if (preg_match('/gps|coordenada|plano|medición|levantamiento|topografía/', $textoLower)) return 'referencia técnica';
        if (preg_match('/predio|terreno|lindero|colindancia|parcela|superficie/', $textoLower)) return 'referencia espacial';
        
        return 'hecho';
    }
    
    private function determinarFuente($texto) {
        $textoLower = strtolower($texto);
        
        if (preg_match('/(?:el|la|por)\s+(?:actor|parte actora|demandante|quejoso)/', $textoLower)) return 'parte actora';
        if (preg_match('/(?:el|la|por)\s+(?:demandado|parte demandada|demandada)/', $textoLower)) return 'parte demandada';
        if (preg_match('/(?:juzgado|tribunal|juez|magistrado|autoridad|sentencia)/', $textoLower)) return 'autoridad';
        if (preg_match('/(?:escritura|registro público|notaría|notario|público)/', $textoLower)) return 'documento público';
        if (preg_match('/(?:contrato privado|convenio|acuerdo|privado)/', $textoLower)) return 'documento privado';
        
        return 'tercero';
    }
    
    private function determinarNaturaleza($fecha) {
        if (preg_match('/19\d{2}/', $fecha)) return 'histórica';
        if (preg_match('/202[0-9]/', $fecha)) return 'contemporánea al conflicto';
        return 'antecedente';
    }
    
    private function determinarVerificable($texto) {
        $textoLower = strtolower($texto);
        
        if (preg_match('/documento|escritura|registro|plano|gps|coordenada|medición/', $textoLower)) return 'sí';
        if (preg_match('/testimonial|testigo|declaración|manifestó|dijo/', $textoLower)) return 'parcial';
        
        return 'no';
    }
    
    private function determinarRelacion($texto) {
        $textoLower = strtolower($texto);
        
        if (preg_match('/objeto|litis|controversia|objeto del juicio|objeto del debate/', $textoLower)) return 'directa';
        if (preg_match('/antecedente|referencia|menciona|señala/', $textoLower)) return 'indirecta';
        
        return 'contextual';
    }
    
    private function determinarPretension($texto) {
        if (preg_match('/(?:acreditar|demostrar|probar|evidenciar|pretende|solicita|pide)\s+(?:que\s+)?([^\.]+)/i', $texto, $matches)) {
            return trim($matches[1]);
        }
        
        return 'No especificado';
    }
    
    private function extraerDescripcion($linea, $fecha) {
        $descripcion = str_replace($fecha, '', $linea);
        $descripcion = preg_replace('/\s+/', ' ', $descripcion);
        $descripcion = trim($descripcion);
        
        if (empty($descripcion)) {
            $descripcion = trim($linea);
        }
        
        return $descripcion;
    }
    
    private function ordenarEventos() {
        usort($this->eventos, function($a, $b) {
            if ($a['timestamp'] == $b['timestamp']) {
                return $a['pagina'] - $b['pagina'];
            }
            return $a['timestamp'] - $b['timestamp'];
        });
    }
}
?>