<?php
/**
 * Funciones para sistema de cupones QR - VERSIÓN MEJORADA
 * Sistema de dos pasos: Validación + Redención
 */

/**
 * Generar código QR único para cupón
 */
function generarCodigoQRUnico($pdo, $cupon_asignado_id) {
    try {
        // Generar string único más corto
        $unique_string = 'TLAXCALITA_' . time() . '_' . $cupon_asignado_id . '_' . bin2hex(random_bytes(8));
        $qr_code = 'TLAX_' . substr(md5($unique_string), 0, 32);
        
        // Guardar en base de datos
        $stmt = $pdo->prepare("
            UPDATE cupones_asignados 
            SET qr_code = ? 
            WHERE id = ?
        ");
        $stmt->execute([$qr_code, $cupon_asignado_id]);
        
        return $qr_code;
        
    } catch (Exception $e) {
        error_log("Error generando QR: " . $e->getMessage());
        return null;
    }
}

/**
 * Obtener URL para validación QR
 */
function getQRValidationURL($qr_code, $base_url = 'https://tlaxcalitabeach.com') {
    return $base_url . '/califica/validate_coupon.php?qr=' . urlencode($qr_code);
}

/**
 * Generar imagen QR (usando API o librería local)
 */
function generarImagenQR($qr_data, $size = 300) {
    // Usar API confiable
    $encoded_data = urlencode($qr_data);
    return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data={$encoded_data}&format=png&margin=10&color=000000&bgcolor=FFFFFF";
}

/**
 * VALIDAR cupón por código QR (SOLO VALIDACIÓN, NO REDENCIÓN)
 * Primer paso del sistema de dos pasos
 */
function validarCuponQR($pdo, $qr_code, $validated_by = 'scanner') {
    try {
        // Limpiar el código QR (eliminar espacios, saltos de línea)
        $qr_code = trim($qr_code);
        
        // DEBUG: Log para ver qué código se está buscando
        error_log("Buscando cupón con QR: " . substr($qr_code, 0, 50));
        
        // 1. Buscar cupón por QR
        $stmt = $pdo->prepare("
            SELECT 
                ca.*, 
                cp.codigo as cupon_codigo, 
                cp.descripcion, 
                cp.descuento_valor, 
                cp.descuento_tipo,
                cp.fecha_inicio,
                cp.fecha_fin,
                cp.uso_maximo,
                cp.usos_actuales,
                cp.condiciones,
                -- Verificar si ya fue escaneado antes
                (SELECT COUNT(*) FROM cupones_qr_scans 
                 WHERE cupon_asignado_id = ca.id 
                 AND scan_type = 'validation_scan'
                 AND scan_result = 'success') as veces_escaneado,
                -- Verificar si ya fue redimido
                (SELECT COUNT(*) FROM cupones_redenciones 
                 WHERE cupon_asignado_id = ca.id) as veces_redimido
            FROM cupones_asignados ca
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE ca.qr_code = ?
        ");
        $stmt->execute([$qr_code]);
        
        if ($stmt->rowCount() === 0) {
            // Intentar buscar sin el prefijo TLAX_ si existe
            if (strpos($qr_code, 'TLAX_') === 0) {
                $qr_sin_prefijo = substr($qr_code, 5);
                $stmt->execute([$qr_sin_prefijo]);
                
                if ($stmt->rowCount() === 0) {
                    return [
                        'success' => false,
                        'message' => '❌ Cupón no encontrado. Código: ' . substr($qr_code, 0, 20) . '...',
                        'code' => 'NOT_FOUND',
                        'action' => 'validar'
                    ];
                }
            } else {
                return [
                    'success' => false,
                    'message' => '❌ Cupón no encontrado. Código: ' . substr($qr_code, 0, 20) . '...',
                    'code' => 'NOT_FOUND',
                    'action' => 'validar'
                ];
            }
        }
        
        $cupon = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // DEBUG: Log del cupón encontrado
        error_log("Cupón encontrado - ID: " . $cupon['id'] . ", Estado: " . $cupon['estado']);
        
        // 2. Verificar si YA FUE REDIMIDO
        if ($cupon['veces_redimido'] > 0) {
            return [
                'success' => false,
                'message' => '❌ Este cupón ya fue redimido anteriormente',
                'code' => 'ALREADY_REDEEMED',
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id'], // ID del cupón asignado
                    'usuario' => $cupon['usuario_nombre'],
                    'fecha_redimido' => $cupon['fecha_redimido']
                ],
                'action' => 'validar'
            ];
        }
        
        // 3. Verificar estado actual
        if ($cupon['estado'] === 'redimido') {
            return [
                'success' => false,
                'message' => '❌ Cupón ya redimido',
                'code' => 'REDEEMED',
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id']
                ],
                'action' => 'validar'
            ];
        }
        
        if ($cupon['estado'] === 'expirado' || $cupon['estado'] === 'cancelado') {
            return [
                'success' => false,
                'message' => '❌ Cupón no disponible (' . $cupon['estado'] . ')',
                'code' => strtoupper($cupon['estado']),
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id']
                ],
                'action' => 'validar'
            ];
        }
        
        // 4. Verificar fechas de vigencia
        $hoy = date('Y-m-d');
        
        if (!empty($cupon['fecha_fin']) && $cupon['fecha_fin'] < $hoy) {
            // Marcar como expirado
            $pdo->prepare("UPDATE cupones_asignados SET estado = 'expirado' WHERE id = ?")
                ->execute([$cupon['id']]);
                
            return [
                'success' => false,
                'message' => '❌ Cupón expirado',
                'code' => 'EXPIRED',
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id']
                ],
                'action' => 'validar'
            ];
        }
        
        if (!empty($cupon['fecha_inicio']) && $cupon['fecha_inicio'] > $hoy) {
            return [
                'success' => false,
                'message' => '❌ Cupón aún no está vigente (inicia: ' . $cupon['fecha_inicio'] . ')',
                'code' => 'NOT_ACTIVE',
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id']
                ],
                'action' => 'validar'
            ];
        }
        
        // 5. Verificar límite de usos del cupón promocional
        if ($cupon['uso_maximo'] > 0 && $cupon['usos_actuales'] >= $cupon['uso_maximo']) {
            return [
                'success' => false,
                'message' => '❌ Este tipo de cupón ha alcanzado su límite de usos',
                'code' => 'MAX_USED',
                'cupon' => [
                    'id' => $cupon['id'],
                    'id_asignado' => $cupon['id']
                ],
                'action' => 'validar'
            ];
        }
        
        // 6. Registrar el SCAN de validación (NO la redención)
        $stmt_scan = $pdo->prepare("
            INSERT INTO cupones_qr_scans 
            (cupon_asignado_id, scan_type, scan_result, validated_by, 
             ip_address, device_info)
            VALUES (?, 'validation_scan', 'success', ?, ?, ?)
        ");
        $stmt_scan->execute([
            $cupon['id'],
            $validated_by,
            $_SERVER['REMOTE_ADDR'],
            substr($_SERVER['HTTP_USER_AGENT'], 0, 255)
        ]);
        
        $scan_id = $pdo->lastInsertId();
        
        // 7. Actualizar contador de escaneos en cupón asignado
        $pdo->prepare("
            UPDATE cupones_asignados 
            SET veces_escaneado = COALESCE(veces_escaneado, 0) + 1,
                qr_validated = 1,
                qr_validation_date = NOW()
            WHERE id = ?
        ")->execute([$cupon['id']]);
        
        // 8. Preparar respuesta de validación exitosa
        $descuento_texto = $cupon['descuento_tipo'] == 'porcentaje' 
            ? $cupon['descuento_valor'] . '%' 
            : '$' . number_format($cupon['descuento_valor'], 2);
        
        return [
            'success' => true,
            'message' => '✅ CUPÓN VÁLIDO - Pendiente de redención',
            'code' => 'VALID',
            'action' => 'validar',
            'cupon' => [
                'id' => $cupon['id'], // ¡IMPORTANTE: Este es el ID del cupón ASIGNADO!
                'id_asignado' => $cupon['id'],
                'cupon_id' => $cupon['cupon_id'], // ID del cupón promocional
                'codigo' => $cupon['cupon_codigo'],
                'codigo_cupon' => $cupon['cupon_codigo'],
                'usuario' => $cupon['usuario_nombre'],
                'usuario_nombre' => $cupon['usuario_nombre'],
                'usuario_email' => $cupon['usuario_email'],
                'descuento' => $descuento_texto,
                'descuento_valor' => $cupon['descuento_valor'],
                'descuento_tipo' => $cupon['descuento_tipo'],
                'descripcion' => $cupon['descripcion'],
                'condiciones' => $cupon['condiciones'],
                'fecha_fin' => $cupon['fecha_fin'],
                'fecha_asignacion' => $cupon['fecha_asignacion'],
                'veces_escaneado' => ($cupon['veces_escaneado'] + 1),
                'estado' => $cupon['estado'],
                'qr_code' => $cupon['qr_code'],
                'puede_redimir' => true,
                'redimido_por' => $cupon['redimido_por'],
                'fecha_redimido' => $cupon['fecha_redimido']
            ],
            'metadata' => [
                'scan_id' => $scan_id,
                'timestamp' => date('Y-m-d H:i:s'),
                'next_action' => 'redimir',
                'redemption_required' => true,
                'instructions' => 'Este cupón necesita ser redimido para aplicar el descuento'
            ]
        ];
        
    } catch (Exception $e) {
        error_log("Error validando QR: " . $e->getMessage());
        return [
            'success' => false,
            'message' => '⚠️ Error en el sistema de validación: ' . $e->getMessage(),
            'code' => 'SYSTEM_ERROR',
            'action' => 'validar',
            'error_details' => $e->getMessage()
        ];
    }
}

/**
 * Obtener información del cupón por QR (solo lectura)
 */
function getCuponInfoByQR($pdo, $qr_code) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                ca.*,
                cp.codigo as cupon_codigo,
                cp.descripcion,
                cp.descuento_tipo,
                cp.descuento_valor,
                cp.fecha_inicio,
                cp.fecha_fin,
                cp.condiciones,
                cp.uso_maximo,
                cp.usos_actuales,
                -- Verificar redenciones
                (SELECT COUNT(*) FROM cupones_redenciones cr WHERE cr.cupon_asignado_id = ca.id) as veces_redimido,
                -- Última redención
                (SELECT MAX(fecha_redencion) FROM cupones_redenciones cr WHERE cr.cupon_asignado_id = ca.id) as ultima_redencion,
                -- Total escaneos
                (SELECT COUNT(*) FROM cupones_qr_scans cqs WHERE cqs.cupon_asignado_id = ca.id) as total_escaneos
            FROM cupones_asignados ca
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE ca.qr_code = ?
        ");
        $stmt->execute([$qr_code]);
        
        if ($stmt->rowCount() === 0) {
            return null;
        }
        
        $cupon = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Determinar estado display
        $estado_display = $cupon['estado'];
        if ($cupon['veces_redimido'] > 0) {
            $estado_display = 'redimido';
        } elseif (!empty($cupon['fecha_fin']) && $cupon['fecha_fin'] < date('Y-m-d')) {
            $estado_display = 'expirado';
        }
        
        $cupon['estado_display'] = $estado_display;
        $cupon['descuento_texto'] = $cupon['descuento_tipo'] == 'porcentaje' 
            ? $cupon['descuento_valor'] . '%' 
            : '$' . number_format($cupon['descuento_valor'], 2);
        
        return $cupon;
        
    } catch (Exception $e) {
        error_log("Error obteniendo info QR: " . $e->getMessage());
        return null;
    }
}

/**
 * Obtener historial de escaneos de un cupón
 */
function getHistorialEscaneos($pdo, $cupon_asignado_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM cupones_qr_scans 
            WHERE cupon_asignado_id = ? 
            ORDER BY scan_timestamp DESC 
            LIMIT 10
        ");
        $stmt->execute([$cupon_asignado_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error obteniendo historial: " . $e->getMessage());
        return [];
    }
}
?>