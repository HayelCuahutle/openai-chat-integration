<?php
// includes/ModoRevisionEditorial.php

class ModoRevisionEditorial {
    private $textoCompleto;
    private $alertas = [];
    private $categoriasUsadas = [];
    
    private $catalogoCategorias = [
        1 => 'Lenguaje con posible carga jurídica o valorativa',
        2 => 'Saltos lógicos entre apartados, secciones o argumentos del documento',
        3 => 'Afirmaciones finales que no encuentran desarrollo explícito previo dentro del propio texto',
        4 => 'Datos, cifras o afirmaciones que aparecen en una sección sin haber sido mencionados previamente',
        5 => 'Ambigüedad terminológica o conceptual dentro del documento',
        6 => 'Ausencia de explicación interna sobre postura, criterio o afirmación adoptada en el texto',
        7 => 'Riesgos de interpretación por redacción poco clara o imprecisa',
        8 => 'Inconsistencias internas entre texto, cifras, tablas o referencias gráficas',
        9 => 'Afirmaciones categóricas sin delimitación contextual suficiente',
        10 => 'Incoherencias numéricas en títulos, numeración, listados o elementos seriados',
        11 => 'Errores de ortografía, gramática, acentuación o puntuación',
        12 => 'Inconsistencias temporales o de secuencia lógica'
    ];
    
    public function __construct($texto) {
        $this->textoCompleto = $texto;
    }
    
    public function generarAnalisis() {
        $respuesta = $this->generarBloqueInformativo();
        $this->analizarDocumento();
        $respuesta .= $this->generarTablaAlertas();
        $respuesta .= $this->generarSintesisEditorial();
        $respuesta .= $this->generarClaveCategorias();
        $respuesta .= $this->generarNotaResponsabilidad();
        
        return $respuesta;
    }
    
    private function generarBloqueInformativo() {
        $partes = $this->extraerPartes();
        $juzgado = $this->extraerJuzgado();
        $expediente = $this->extraerExpediente();
        
        $bloque = "\n" . str_repeat("═", 140) . "\n";
        $bloque .= "                     **📝 MODO REVISIÓN EDITORIAL - ANÁLISIS COMPLETO**\n";
        $bloque .= str_repeat("═", 140) . "\n\n";
        
        $bloque .= "**📋 BLOQUE INFORMATIVO**\n";
        $bloque .= str_repeat("─", 140) . "\n";
        $bloque .= "| Campo | Valor |\n";
        $bloque .= "|-------|-------|\n";
        $bloque .= "| **PARTES** | {$partes} |\n";
        $bloque .= "| **JUZGADO** | {$juzgado} |\n";
        $bloque .= "| **EXPEDIENTE** | {$expediente} |\n\n";
        
        return $bloque;
    }
    
    private function extraerPartes() {
        $patrones = [
            '/(?:ACTOR|PARTE ACTORA|DEMANDANTE|QUEJOSO)[\s:]+([^\\n]+).*?(?:DEMANDADO|PARTE DEMANDADA)[\s:]+([^\\n]+)/is',
            '/C\.\s*([^\\n]+?)\s+VS?\s+([^\\n]+)/i',
            '/([^\\n]+?)\s+(?:CONTRA|VS?\.?)\s+([^\\n]+)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                if (count($matches) >= 3) {
                    return trim($matches[1]) . " VS " . trim($matches[2]);
                }
            }
        }
        
        return "No identificable";
    }
    
    private function extraerJuzgado() {
        $patrones = [
            '/(?:JUZGADO|Juzgado|JUECES|JUEZ)[\s:]+([^\\n]+(?:[^\\n]+){0,2})/i',
            '/(?:PRIMERO|SEGUNDO|TERCERO|CUARTO|QUINTO)\s+(?:DE LO CIVIL|CIVIL|FAMILIAR)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                return trim($matches[0]);
            }
        }
        
        return "No identificable";
    }
    
    private function extraerExpediente() {
        $patrones = [
            '/EXPEDIENTE[\s:]+([^\s]+(?:\s*[\/-]\s*[^\s]+)*)/i',
            '/(?:N[°º]\s*)?(\d+[-\/]\d+(?:[-\/]\d+)?)/',
            '/(?:EXP\.?\s*)?(\d+\s*[\/-]\s*\d+(?:\s*[\/-]\s*\d+)?)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                return trim($matches[1] ?? $matches[0]);
            }
        }
        
        return "No identificable";
    }
    
    private function analizarDocumento() {
        $paginas = explode("=== PÁGINA ", $this->textoCompleto);
        $this->alertas = [];
        $this->categoriasUsadas = [];
        
        foreach ($paginas as $index => $pagina) {
            if ($index == 0) continue;
            $numPagina = $index;
            $this->analizarPagina($pagina, $numPagina);
        }
        
        $this->validarEstructural();
    }
    
    private function analizarPagina($texto, $numPagina) {
        $lineas = explode("\n", $texto);
        $textoCompletoPagina = implode(" ", $lineas);
        
        $this->analizarCargaJuridica($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarSaltosLogicos($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarAfirmacionesSinDesarrollo($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarDatosSinMencion($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarAmbiguedad($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarAusenciaExplicacion($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarRedaccionPocoClara($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarInconsistenciasInternas($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarAfirmacionesCategoricas($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarIncoherenciasNumericas($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarErroresOrtograficos($textoCompletoPagina, $numPagina, $lineas);
        $this->analizarInconsistenciasTemporales($textoCompletoPagina, $numPagina, $lineas);
    }
    
    private function analizarCargaJuridica($texto, $pagina, $lineas) {
        $patrones = [
            '/\b(?:indubitablemente|incuestionablemente|definitivamente|absolutamente)\b/i',
            '/\b(?:propietario legítimo|legítimo derecho|título legítimo)\b/i',
            '/\b(?:posesión originaria|derecho real|usucapión|prescripción adquisitiva)\b/i',
            '/\b(?:violación|quebrantamiento|contravención)\s+(?:de|a|del)\s+(?:derecho|ley|norma)\b/i'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($patrones as $patron) {
                if (preg_match($patron, $linea, $matches)) {
                    $this->agregarAlerta(
                        1,
                        $pagina,
                        $this->determinarApartado($linea, $numLinea),
                        $matches[0],
                        "Uso de lenguaje con posible carga jurídica o valorativa",
                        $this->determinarRiesgo($patron)
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarSaltosLogicos($texto, $pagina, $lineas) {
        if (preg_match('/(?:sin embargo|no obstante|empero|pero)\s+(?:[^.]*\.){0,2}\s*(?:como se dijo|anteriormente|previamente)/i', $texto, $matches)) {
            $this->agregarAlerta(
                2, $pagina,
                "Sección media",
                substr($matches[0], 0, 100) . "...",
                "Posible salto lógico en la argumentación",
                "MEDIO"
            );
        }
    }
    
    private function analizarAfirmacionesSinDesarrollo($texto, $pagina, $lineas) {
        $patronesAfirmaciones = [
            '/\b(?:por lo tanto|en consecuencia|así pues|de lo anterior se concluye)\b.*?[.!?]/i',
            '/\b(?:queda demostrado|ha quedado acreditado|resulta evidente)\b.*?[.!?]/i'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($patronesAfirmaciones as $patron) {
                if (preg_match($patron, $linea, $matches)) {
                    $this->agregarAlerta(
                        3, $pagina,
                        $this->determinarApartado($linea, $numLinea),
                        substr($matches[0], 0, 100) . "...",
                        "Afirmación conclusiva sin desarrollo previo suficiente",
                        "ALTO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarDatosSinMencion($texto, $pagina, $lineas) {
        foreach ($lineas as $numLinea => $linea) {
            if (preg_match_all('/\b(\d+[,.]?\d*)\s*(?:metros|hectáreas|m2|ha|pesos|dólares)\b/i', $linea, $matches)) {
                foreach ($matches[0] as $dato) {
                    $textoPrevio = substr($this->textoCompleto, 0, strpos($this->textoCompleto, $linea));
                    if (!preg_match('/' . preg_quote($dato, '/') . '/i', $textoPrevio)) {
                        $this->agregarAlerta(
                            4, $pagina,
                            $this->determinarApartado($linea, $numLinea),
                            $dato,
                            "Dato que aparece sin mención previa",
                            "MEDIO"
                        );
                        break;
                    }
                }
            }
        }
    }
    
    private function analizarAmbiguedad($texto, $pagina, $lineas) {
        $terminosAmbiguos = [
            '/\b(?:aproximadamente|cerca de|alrededor de)\s*\d+/i',
            '/\b(?:etcétera|etc\.|y\s+otros|y\s+demás)\b/i',
            '/\b(?:posiblemente|probablemente|quizás|tal vez)\b/i'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($terminosAmbiguos as $patron) {
                if (preg_match($patron, $linea, $matches)) {
                    $this->agregarAlerta(
                        5, $pagina,
                        $this->determinarApartado($linea, $numLinea),
                        $matches[0],
                        "Ambigüedad terminológica",
                        "BAJO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarAusenciaExplicacion($texto, $pagina, $lineas) {
        $conceptos = [
            '/\b(?:criterio|metodología|procedimiento|técnica)\s+(?:utilizada|aplicada)\b/i',
            '/\b(?:postura|posición|argumento|tesis)\s+(?:adoptada|asumida)\b/i',
            '/\b(?:fundamento|base|razón|motivo)\s+(?:de|para)\b/i'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($conceptos as $patron) {
                if (preg_match($patron, $linea, $matches)) {
                    $this->agregarAlerta(
                        6, $pagina,
                        $this->determinarApartado($linea, $numLinea),
                        $matches[0],
                        "Concepto mencionado sin explicación suficiente",
                        "ALTO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarRedaccionPocoClara($texto, $pagina, $lineas) {
        foreach ($lineas as $numLinea => $linea) {
            if (preg_match('/\b(?:[^.]{200,})\b/', $linea)) {
                $this->agregarAlerta(
                    7, $pagina,
                    $this->determinarApartado($linea, $numLinea),
                    substr($linea, 0, 100) . "...",
                    "Redacción poco clara",
                    "MEDIO"
                );
                break;
            }
        }
    }
    
    private function analizarInconsistenciasInternas($texto, $pagina, $lineas) {
        if (preg_match_all('/\b(?:tabla|cuadro|figura|gráfica)\s+(\d+)\b/i', $texto, $referencias)) {
            foreach ($referencias[1] as $numRef) {
                if (!preg_match('/\b(?:tabla|cuadro|figura|gráfica)\s+' . $numRef . '\s*[:.].{0,200}/i', $texto)) {
                    $this->agregarAlerta(
                        8, $pagina,
                        "Referencias",
                        "Tabla/Figura {$numRef}",
                        "Referencia a elemento inexistente",
                        "ALTO"
                    );
                }
            }
        }
    }
    
    private function analizarAfirmacionesCategoricas($texto, $pagina, $lineas) {
        $patronesCategoricos = [
            '/\b(?:siempre|nunca|jamás|todos|ninguno|absolutamente)\b/i',
            '/\b(?:es\s+(?:indudable|incuestionable|innegable))\b/i'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($patronesCategoricos as $patron) {
                if (preg_match($patron, $linea, $matches)) {
                    if (!preg_match('/(?:en\s+este\s+caso|bajo\s+estas\s+circunstancias)/i', $linea)) {
                        $this->agregarAlerta(
                            9, $pagina,
                            $this->determinarApartado($linea, $numLinea),
                            $matches[0],
                            "Afirmación categórica sin delimitación contextual",
                            "ALTO"
                        );
                        break;
                    }
                }
            }
        }
    }
    
    private function analizarIncoherenciasNumericas($texto, $pagina, $lineas) {
        $numeracion = [];
        foreach ($lineas as $linea) {
            if (preg_match('/^(?:PRIMERO|SEGUNDO|TERCERO|1\.|2\.|3\.|I\.|II\.|III\.)/i', trim($linea), $matches)) {
                $numeracion[] = $matches[0];
            }
        }
        
        for ($i = 1; $i < count($numeracion); $i++) {
            if (preg_match('/(\d+)/', $numeracion[$i-1], $numAnt) && preg_match('/(\d+)/', $numeracion[$i], $numAct)) {
                if ($numAct[1] != $numAnt[1] + 1) {
                    $this->agregarAlerta(
                        10, $pagina,
                        "Numeración",
                        "Salto de {$numAnt[1]} a {$numAct[1]}",
                        "Incoherencia en la numeración",
                        "MEDIO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarErroresOrtograficos($texto, $pagina, $lineas) {
        $erroresComunes = [
            '/\b(a ver|haber)\s+(?:de|que)\b/i' => 'Confusión "a ver/haber"',
            '/\b(ha|a)\s+(?:sido|estado|hecho)\b/i' => 'Confusión "ha/a"',
            '/\b(echo|hecho)\s+(?:de|en)\b/i' => 'Confusión "echo/hecho"',
            '/\b(aya|haya|allá)\b/i' => 'Confusión "aya/haya/allá"'
        ];
        
        foreach ($lineas as $numLinea => $linea) {
            foreach ($erroresComunes as $patron => $descripcion) {
                if (preg_match($patron, $linea, $matches)) {
                    $this->agregarAlerta(
                        11, $pagina,
                        $this->determinarApartado($linea, $numLinea),
                        $matches[0],
                        "Error ortográfico: " . $descripcion,
                        "BAJO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarInconsistenciasTemporales($texto, $pagina, $lineas) {
        $patronFecha = '/(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{1,2}\s+de\s+[a-zA-Z]+\s+de\s+\d{4})/';
        
        if (preg_match_all($patronFecha, $texto, $matches) && count($matches[0]) > 1) {
            $this->agregarAlerta(
                12, $pagina,
                "Secuencia temporal",
                "Múltiples fechas encontradas",
                "Posible inconsistencia temporal",
                "MEDIO"
            );
        }
    }
    
    private function determinarApartado($linea, $numLinea) {
        if (preg_match('/^(?:PRIMERO|SEGUNDO|TERCERO|I\.|II\.|III\.|1\.|2\.|3\.)/i', trim($linea), $matches)) {
            return $matches[0];
        }
        return "Línea " . ($numLinea + 1);
    }
    
    private function determinarRiesgo($patron) {
        if (preg_match('/indubitablemente|incuestionablemente|definitivamente/', $patron)) return "ALTO";
        if (preg_match('/propietario legítimo|legítimo derecho/', $patron)) return "MEDIO";
        return "BAJO";
    }
    
    private function agregarAlerta($categoria, $pagina, $apartado, $referencia, $motivo, $riesgo) {
        $numAlerta = count($this->alertas) + 1;
        
        $this->alertas[] = [
            'num' => $numAlerta,
            'categoria' => $categoria,
            'pagina' => $pagina,
            'apartado' => $apartado,
            'referencia' => $referencia,
            'motivo' => $motivo,
            'riesgo' => $riesgo,
            'notas' => '',
            'atendido' => ''
        ];
        
        if (!in_array($categoria, $this->categoriasUsadas)) {
            $this->categoriasUsadas[] = $categoria;
        }
    }
    
    private function generarTablaAlertas() {
        if (empty($this->alertas)) {
            return "**✅ No se detectaron alertas editoriales en el documento.**\n\n";
        }
        
        $tabla = "\n**⚠️ TABLA ÚNICA DE ALERTAS EDITORIALES**\n";
        $tabla .= str_repeat("─", 140) . "\n\n";
        $tabla .= "| Nº | Categoría | Página | Apartado / Sección | Referencia textual breve | Motivo técnico o formal | Nivel de riesgo | Notas | Atendido |\n";
        $tabla .= "|----|-----------|--------|---------------------|-------------------------|-------------------------|-----------------|-------|----------|\n";
        
        foreach ($this->alertas as $alerta) {
            $referencia = str_replace(["\n", "\r"], " ", $alerta['referencia']);
            $referencia = substr($referencia, 0, 50) . (strlen($referencia) > 50 ? '...' : '');
            
            $tabla .= sprintf("| %d | %d | %d | %s | %s | %s | %s | | |\n",
                $alerta['num'],
                $alerta['categoria'],
                $alerta['pagina'],
                $alerta['apartado'],
                $referencia,
                $alerta['motivo'],
                $alerta['riesgo']
            );
        }
        
        $tabla .= "\n";
        return $tabla;
    }
    
    private function generarSintesisEditorial() {
        $totalAlertas = count($this->alertas);
        $riesgoAlto = count(array_filter($this->alertas, fn($a) => $a['riesgo'] === 'ALTO'));
        $riesgoMedio = count(array_filter($this->alertas, fn($a) => $a['riesgo'] === 'MEDIO'));
        
        $sintesis = "\n**📊 SÍNTESIS EDITORIAL PARA DECISIÓN DEL PERITO**\n";
        $sintesis .= str_repeat("─", 140) . "\n\n";
        $sintesis .= "| Indicador | Valor |\n";
        $sintesis .= "|-----------|-------|\n";
        $sintesis .= "| Nivel general de coherencia documental | " . $this->evaluarCoherencia() . " |\n";
        $sintesis .= "| Grado de claridad estructural | " . $this->evaluarClaridad() . " |\n";
        $sintesis .= "| Alertas detectadas | {$totalAlertas} (Alto: {$riesgoAlto}, Medio: {$riesgoMedio}) |\n\n";
        
        return $sintesis;
    }
    
    private function evaluarCoherencia() {
        $alertasEstructurales = count(array_filter($this->alertas, fn($a) => in_array($a['categoria'], [2, 3, 8, 10, 12])));
        if ($alertasEstructurales == 0) return "ALTA";
        if ($alertasEstructurales <= 2) return "MEDIA";
        return "BAJA";
    }
    
    private function evaluarClaridad() {
        $alertasClaridad = count(array_filter($this->alertas, fn($a) => in_array($a['categoria'], [5, 7, 11])));
        if ($alertasClaridad == 0) return "ALTA";
        if ($alertasClaridad <= 2) return "MEDIA";
        return "BAJA";
    }
    
    private function generarClaveCategorias() {
        sort($this->categoriasUsadas);
        
        $clave = "\n**🔑 CLAVE DE CATEGORÍAS UTILIZADAS**\n";
        $clave .= str_repeat("─", 140) . "\n\n";
        
        foreach ($this->categoriasUsadas as $cat) {
            $clave .= "**{$cat}.** " . $this->catalogoCategorias[$cat] . "\n";
        }
        
        return $clave;
    }
    
    private function validarEstructural() {
        $categoriasEnTabla = array_unique(array_column($this->alertas, 'categoria'));
        sort($categoriasEnTabla);
        
        foreach ($categoriasEnTabla as $cat) {
            if ($cat < 1 || $cat > 12) {
                $this->alertas = array_filter($this->alertas, fn($a) => $a['categoria'] != $cat);
            }
        }
        
        $this->categoriasUsadas = array_unique($categoriasEnTabla);
        sort($this->categoriasUsadas);
    }
    
    private function generarNotaResponsabilidad() {
        $nota = "\n" . str_repeat("═", 140) . "\n";
        $nota .= "**⚖️ NOTA DE RESPONSABILIDAD**\n";
        $nota .= str_repeat("═", 140) . "\n";
        $nota .= "Mextopo es un asistente de inteligencia artificial utilizado como\n";
        $nota .= "herramienta de apoyo. El contenido generado puede contener errores\n";
        $nota .= "u omisiones. La revisión final y la responsabilidad del dictamen\n";
        $nota .= "corresponden exclusivamente al perito firmante.\n";
        $nota .= str_repeat("═", 140) . "\n";
        
        return $nota;
    }
}
?>