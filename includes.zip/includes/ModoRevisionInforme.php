<?php
// includes/ModoRevisionInforme.php

class ModoRevisionInforme {
    private $textoCompleto;
    private $observaciones = [];
    private $categoriasUsadas = [];
    
    private $catalogoCategorias = [
        'A' => 'Inconsistencias estructurales o de secuencia lógica',
        'B' => 'Ambigüedad técnica o conceptual',
        'C' => 'Cadena lógica incompleta entre datos, análisis y conclusiones',
        'D' => 'Deficiencia en declaración de marco geodésico o sistema de referencia',
        'E' => 'Justificación técnica insuficiente del procedimiento o equipo declarado',
        'F' => 'Inconsistencias entre texto, tablas o planos referidos',
        'G' => 'Uso impreciso de terminología especializada',
        'H' => 'Supuestos implícitos no declarados expresamente',
        'I' => 'Omisión de delimitación de alcance o condiciones del trabajo',
        'J' => 'Inconsistencias numéricas internas',
        'K' => 'Redacción poco clara o construcción sintáctica ambigua',
        'L' => 'Errores de ortografía, gramática o puntuación'
    ];
    
    public function __construct($texto) {
        $this->textoCompleto = $texto;
    }
    
    public function generarAnalisis() {
        $this->analizarInforme();
        
        $respuesta = $this->generarTablaObservaciones();
        $respuesta .= $this->generarEvaluacionGlobal();
        $respuesta .= $this->generarClaveCategorias();
        $respuesta .= $this->generarNotaResponsabilidad();
        
        return $respuesta;
    }
    
    private function analizarInforme() {
        $paginas = explode("=== PÁGINA ", $this->textoCompleto);
        
        foreach ($paginas as $index => $pagina) {
            if ($index == 0) continue;
            $numPagina = $index;
            $this->analizarPagina($pagina, $numPagina);
        }
        
        $this->validarEstructural();
    }
    
    private function analizarPagina($texto, $pagina) {
        $this->analizarInconsistenciasEstructurales($texto, $pagina);
        $this->analizarAmbiguedadTecnica($texto, $pagina);
        $this->analizarCadenaLogica($texto, $pagina);
        $this->analizarMarcoGeodesico($texto, $pagina);
        $this->analizarJustificacionTecnica($texto, $pagina);
        $this->analizarInconsistenciasGraficas($texto, $pagina);
        $this->analizarTerminologia($texto, $pagina);
        $this->analizarSupuestosImplicitos($texto, $pagina);
        $this->analizarAlcance($texto, $pagina);
        $this->analizarInconsistenciasNumericas($texto, $pagina);
        $this->analizarRedaccion($texto, $pagina);
        $this->analizarErroresOrtograficos($texto, $pagina);
    }
    
    private function analizarInconsistenciasEstructurales($texto, $pagina) {
        $tieneIntroduccion = preg_match('/\b(?:introducción|antecedentes|objetivo|propósito)\b/i', $texto);
        
        if ($pagina == 1 && !$tieneIntroduccion) {
            $this->agregarObservacion(
                'A', $pagina,
                "Inicio",
                "Sin introducción",
                "El informe carece de introducción que contextualice el trabajo",
                "MEDIO"
            );
        }
    }
    
    private function analizarAmbiguedadTecnica($texto, $pagina) {
        $terminosAmbiguos = [
            '/\b(?:aproximadamente|cerca de|alrededor de)\s+\d+/i',
            '/\b(?:varios factores|diversos elementos|múltiples aspectos)\b/i'
        ];
        
        foreach ($terminosAmbiguos as $patron) {
            if (preg_match($patron, $texto, $matches)) {
                $this->agregarObservacion(
                    'B', $pagina,
                    "Términos ambiguos",
                    $matches[0],
                    "Uso de terminología ambigua",
                    "MEDIO"
                );
                break;
            }
        }
    }
    
    private function analizarCadenaLogica($texto, $pagina) {
        if (preg_match('/\b(?:dato|medición|coordenada|valor)\b.*?(\d+[.,]?\d*)/i', $texto, $dato)) {
            $datoValor = $dato[1];
            $textoPosterior = substr($this->textoCompleto, strpos($this->textoCompleto, $texto) + strlen($texto));
            if (!preg_match('/' . preg_quote($datoValor, '/') . '/i', $textoPosterior)) {
                $this->agregarObservacion(
                    'C', $pagina,
                    "Datos",
                    "Dato: {$datoValor}",
                    "Dato no utilizado en análisis posteriores",
                    "MEDIO"
                );
            }
        }
    }
    
    private function analizarMarcoGeodesico($texto, $pagina) {
        $marcos = ['ITRF', 'WGS84', 'NAD27', 'NAD83', 'SIRGAS'];
        $mencionados = [];
        
        foreach ($marcos as $marco) {
            if (stripos($texto, $marco) !== false) {
                $mencionados[] = $marco;
            }
        }
        
        if (empty($mencionados)) {
            $this->agregarObservacion(
                'D', $pagina,
                "Marco geodésico",
                "No mencionado",
                "No se declara el marco geodésico utilizado",
                "ALTO"
            );
        }
    }
    
    private function analizarJustificacionTecnica($texto, $pagina) {
        if (preg_match('/\b(?:GPS|estación total|nivel|drone|teodolito)\b/i', $texto, $equipo)) {
            $contexto = substr($texto, max(0, strpos($texto, $equipo[0]) - 100), 200);
            if (!preg_match('/(?:precisión|exactitud|tolerancia|adecuado|justificación)/i', $contexto)) {
                $this->agregarObservacion(
                    'E', $pagina,
                    "Equipo",
                    $equipo[0],
                    "Equipo mencionado sin justificación de idoneidad",
                    "MEDIO"
                );
            }
        }
    }
    
    private function analizarInconsistenciasGraficas($texto, $pagina) {
        if (preg_match_all('/\b(?:tabla|cuadro|figura|plano|gráfica)\s+(\d+)\b/i', $texto, $referencias)) {
            foreach ($referencias[0] as $ref) {
                $contexto = substr($texto, max(0, strpos($texto, $ref) - 50), 150);
                if (!preg_match('/(?:véase|ver|como se muestra|presenta|indica)/i', $contexto)) {
                    $this->agregarObservacion(
                        'F', $pagina,
                        "Gráficos",
                        $ref,
                        "Referencia sin descripción clara",
                        "BAJO"
                    );
                    break;
                }
            }
        }
    }
    
    private function analizarTerminologia($texto, $pagina) {
        $terminosImprecisos = ['cosa', 'algo', 'eso', 'ello', 'etcétera', 'etc.'];
        
        foreach ($terminosImprecisos as $termino) {
            if (stripos($texto, $termino) !== false) {
                $this->agregarObservacion(
                    'G', $pagina,
                    "Terminología",
                    $termino,
                    "Uso de terminología imprecisa",
                    "BAJO"
                );
                break;
            }
        }
    }
    
    private function analizarSupuestosImplicitos($texto, $pagina) {
        $patrones = ['asumiendo', 'suponiendo', 'considerando', 'dado que'];
        
        foreach ($patrones as $patron) {
            if (stripos($texto, $patron) !== false) {
                $this->agregarObservacion(
                    'H', $pagina,
                    "Supuestos",
                    $patron,
                    "Supuesto no declarado explícitamente",
                    "MEDIO"
                );
                break;
            }
        }
    }
    
    private function analizarAlcance($texto, $pagina) {
        if ($pagina <= 2) {
            $tieneAlcance = preg_match('/\b(?:alcance|objeto|propósito|finalidad|objetivo)\b/i', $texto);
            if (!$tieneAlcance) {
                $this->agregarObservacion(
                    'I', $pagina,
                    "Alcance",
                    "No definido",
                    "No se define el alcance del trabajo",
                    "ALTO"
                );
            }
        }
    }
    
    private function analizarInconsistenciasNumericas($texto, $pagina) {
        if (preg_match_all('/\b(\d+[.,]?\d*)\s*(?:m|metros|ha|hectáreas|m2)\b/i', $texto, $matches)) {
            $numeros = $matches[1];
            if (count($numeros) > 1) {
                $max = max($numeros);
                $min = min($numeros);
                if ($max / $min > 10) {
                    $this->agregarObservacion(
                        'J', $pagina,
                        "Cifras",
                        "Rango {$min}-{$max}",
                        "Posible inconsistencia numérica",
                        "MEDIO"
                    );
                }
            }
        }
    }
    
    private function analizarRedaccion($texto, $pagina) {
        $lineas = explode("\n", $texto);
        foreach ($lineas as $numLinea => $linea) {
            if (strlen($linea) > 300) {
                $this->agregarObservacion(
                    'K', $pagina,
                    "Línea " . ($numLinea + 1),
                    "Oración larga",
                    "Oración excesivamente larga",
                    "BAJO"
                );
                break;
            }
        }
    }
    
    private function analizarErroresOrtograficos($texto, $pagina) {
        $errores = [
            '/\b(a ver|haber)\s+(?:de|que)\b/i' => 'Confusión a ver/haber',
            '/\b(ha|a)\s+(?:sido|estado|hecho)\b/i' => 'Confusión ha/a',
            '/\b(echo|hecho)\s+(?:de|en)\b/i' => 'Confusión echo/hecho'
        ];
        
        foreach ($errores as $patron => $descripcion) {
            if (preg_match($patron, $texto)) {
                $this->agregarObservacion(
                    'L', $pagina,
                    "Ortografía",
                    "Error detectado",
                    $descripcion,
                    "BAJO"
                );
                break;
            }
        }
    }
    
    private function agregarObservacion($categoria, $pagina, $apartado, $referencia, $observacion, $impacto) {
        $num = count($this->observaciones) + 1;
        
        $this->observaciones[] = [
            'num' => $num,
            'categoria' => $categoria,
            'pagina' => $pagina,
            'apartado' => $apartado,
            'referencia' => $referencia,
            'observacion' => $observacion,
            'impacto' => $impacto,
            'notas' => '',
            'atendido' => ''
        ];
        
        if (!in_array($categoria, $this->categoriasUsadas)) {
            $this->categoriasUsadas[] = $categoria;
        }
    }
    
    private function generarTablaObservaciones() {
        if (empty($this->observaciones)) {
            return "\n**✅ No se detectaron observaciones en el informe.**\n\n";
        }
        
        $tabla = "\n**📋 TABLA ÚNICA DE OBSERVACIONES**\n";
        $tabla .= str_repeat("─", 140) . "\n\n";
        $tabla .= "| Nº | Categoría | Página | Apartado / Sección | Referencia textual breve | Observación técnica o editorial | Nivel de impacto | Notas | Atendido |\n";
        $tabla .= "|----|-----------|--------|---------------------|-------------------------|--------------------------------|-------------------|-------|----------|\n";
        
        foreach ($this->observaciones as $obs) {
            $tabla .= sprintf("| %d | %s | %d | %s | %s | %s | %s | | |\n",
                $obs['num'],
                $obs['categoria'],
                $obs['pagina'],
                $obs['apartado'],
                $obs['referencia'],
                $obs['observacion'],
                $obs['impacto']
            );
        }
        
        $tabla .= "\n";
        return $tabla;
    }
    
    private function generarEvaluacionGlobal() {
        $totalObs = count($this->observaciones);
        $impactoAlto = count(array_filter($this->observaciones, fn($o) => $o['impacto'] === 'ALTO'));
        
        $evaluacion = "\n**📊 EVALUACIÓN GLOBAL DEL INFORME**\n";
        $evaluacion .= str_repeat("─", 140) . "\n\n";
        $evaluacion .= "| Indicador | Valor |\n";
        $evaluacion .= "|-----------|-------|\n";
        $evaluacion .= "| Coherencia técnica estructural | " . $this->evaluarCoherencia() . " |\n";
        $evaluacion .= "| Claridad profesional | " . $this->evaluarClaridadProfesional() . " |\n";
        $evaluacion .= "| Robustez descriptiva | " . $this->evaluarRobustez() . " |\n";
        $evaluacion .= "| Riesgo de mala interpretación | " . $this->determinarRiesgoInterpretacion($impactoAlto) . " |\n";
        $evaluacion .= "| Estado general | " . $this->determinarEstadoPreparacion($totalObs, $impactoAlto) . " |\n\n";
        
        return $evaluacion;
    }
    
    private function evaluarCoherencia() {
        $obsEstructurales = count(array_filter($this->observaciones, fn($o) => in_array($o['categoria'], ['A', 'C', 'F'])));
        if ($obsEstructurales == 0) return "ALTA";
        if ($obsEstructurales <= 2) return "MEDIA";
        return "BAJA";
    }
    
    private function evaluarClaridadProfesional() {
        $obsClaridad = count(array_filter($this->observaciones, fn($o) => in_array($o['categoria'], ['B', 'G', 'K'])));
        if ($obsClaridad == 0) return "ALTA";
        if ($obsClaridad <= 2) return "MEDIA";
        return "BAJA";
    }
    
    private function evaluarRobustez() {
        $obsTecnicas = count(array_filter($this->observaciones, fn($o) => in_array($o['categoria'], ['D', 'E', 'H', 'I'])));
        if ($obsTecnicas == 0) return "ALTA";
        if ($obsTecnicas <= 2) return "MEDIA";
        return "BAJA";
    }
    
    private function determinarRiesgoInterpretacion($altos) {
        if ($altos > 0) return "ALTO";
        return "BAJO";
    }
    
    private function determinarEstadoPreparacion($total, $altos) {
        if ($total == 0) return "ÓPTIMO - Listo para entrega";
        if ($altos == 0 && $total <= 3) return "BUENO - Revisiones menores";
        if ($altos <= 2) return "REGULAR - Requiere revisiones";
        return "CRÍTICO - No recomendado sin revisión completa";
    }
    
    private function generarClaveCategorias() {
        sort($this->categoriasUsadas);
        
        $clave = "\n**🔑 CLAVE DE CATEGORÍAS UTILIZADAS**\n";
        $clave .= str_repeat("─", 140) . "\n\n";
        
        foreach ($this->categoriasUsadas as $cat) {
            $clave .= "**{$cat}.** " . $this->catalogoCategorias[$cat] . "\n";
        }
        
        return $clave;
    }
    
    private function validarEstructural() {
        $categoriasEnTabla = array_unique(array_column($this->observaciones, 'categoria'));
        $categoriasValidas = range('A', 'L');
        
        foreach ($categoriasEnTabla as $cat) {
            if (!in_array($cat, $categoriasValidas)) {
                $this->observaciones = array_filter($this->observaciones, fn($o) => $o['categoria'] != $cat);
            }
        }
        
        $this->categoriasUsadas = array_unique(array_column($this->observaciones, 'categoria'));
        sort($this->categoriasUsadas);
    }
    
    private function generarNotaResponsabilidad() {
        $nota = "\n" . str_repeat("═", 140) . "\n";
        $nota .= "**⚖️ NOTA DE RESPONSABILIDAD**\n";
        $nota .= str_repeat("═", 140) . "\n";
        $nota .= "Mextopo es un asistente de inteligencia artificial utilizado como\n";
        $nota .= "herramienta de apoyo. El contenido generado puede contener errores\n";
        $nota .= "u omisiones. La revisión final y la responsabilidad del informe\n";
        $nota .= "corresponden exclusivamente al autor.\n";
        $nota .= str_repeat("═", 140) . "\n";
        
        return $nota;
    }
}
?>