<?php
// includes/ModoDemandaContestacion.php

class ModoDemandaContestacion {
    private $textoCompleto;
    private $delimitacion;
    private $textoDemanda = "";
    private $textoContestacion = "";
    private $hechosDemanda = [];
    private $respuestasContestacion = [];
    
    public function __construct($texto, $delimitacion = null) {
        $this->textoCompleto = $texto;
        $this->delimitacion = $delimitacion;
    }
    
    public function generarAnalisis() {
        // Separar demanda y contestación
        $this->separarDocumentos();
        
        // Extraer hechos de la demanda
        $this->extraerHechosDemanda();
        
        // Extraer respuestas de la contestación
        $this->extraerRespuestasContestacion();
        
        // Generar bloque informativo
        $respuesta = $this->generarBloqueInformativo();
        
        // Generar tabla comparativa
        $respuesta .= $this->generarTablaComparativa();
        
        // Generar bloque final
        $respuesta .= $this->generarBloqueFinal();
        
        return $respuesta;
    }
    
    private function separarDocumentos() {
        // Si hay delimitación del usuario, usarla
        if ($this->delimitacion && $this->delimitacion != 'total') {
            // Ejemplo: "demanda:1-10, contestacion:11-20"
            if (preg_match('/demanda:(\d+)-(\d+).*contestacion:(\d+)-(\d+)/i', $this->delimitacion, $matches)) {
                $this->textoDemanda = $this->extraerPaginas($matches[1], $matches[2]);
                $this->textoContestacion = $this->extraerPaginas($matches[3], $matches[4]);
                return;
            }
        }
        
        // Intentar separar automáticamente
        $this->separarAutomaticamente();
    }
    
    private function extraerPaginas($inicio, $fin) {
        $paginas = explode("=== PÁGINA ", $this->textoCompleto);
        $texto = "";
        for ($i = $inicio; $i <= $fin; $i++) {
            if (isset($paginas[$i])) {
                $texto .= $paginas[$i] . "\n";
            }
        }
        return $texto;
    }
    
    private function separarAutomaticamente() {
        $marcadores = [
            '/(?:DEMANDA|ESCRITO INICIAL).*?(?:CONTESTACI[OÓ]N|CONTESTA)/is',
            '/C\.\s*JU[EÉ]Z.*?\.(.*?)(?:POR\s+TANTO|CONTESTACI[OÓ]N)/is',
            '/(?:HECHOS|PRESTACIONES).*?(?:CONTESTA|RESPONDE)/is'
        ];
        
        foreach ($marcadores as $marcador) {
            if (preg_match($marcador, $this->textoCompleto, $matches, PREG_OFFSET_CAPTURE)) {
                $posicion = $matches[0][1];
                $this->textoDemanda = substr($this->textoCompleto, 0, $posicion);
                $this->textoContestacion = substr($this->textoCompleto, $posicion + strlen($matches[0][0]));
                return;
            }
        }
        
        $this->textoDemanda = $this->textoCompleto;
        $this->textoContestacion = "";
    }
    
    private function extraerHechosDemanda() {
        $patrones = [
            '/(?:PRIMERO?|SEGUNDO?|TERCERO?|CUARTO|QUINTO|SEXTO|S[EÉ]PTIMO|OCTAVO|NOVENO|D[EÉ]CIMO)\s*[.:-]\s*([^\\n]+(?:\\n[^\\n]+){0,3})/i',
            '/(?:^|\\n)(\\d+)[.:)]\\s*([^\\n]+(?:\\n[^\\n]+){0,3})/i',
            '/HECHO\s+(?:\\d+)?[.:-]\\s*([^\\n]+(?:\\n[^\\n]+){0,3})/i',
            '/(?:EL|LA|LOS|LAS)\\s+(?:ACTOR|DEMANDANTE|QUEJOSO)\\s+([^\\n]+(?:\\n[^\\n]+){0,2})/i'
        ];
        
        $hechosEncontrados = [];
        
        foreach ($patrones as $patron) {
            if (preg_match_all($patron, $this->textoDemanda, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $hecho = end($match);
                    $hecho = trim(preg_replace('/\s+/', ' ', $hecho));
                    
                    if (strlen($hecho) > 20 && !in_array($hecho, $hechosEncontrados)) {
                        $hechosEncontrados[] = $hecho;
                        
                        $pos = strpos($this->textoDemanda, substr($hecho, 0, 30));
                        $pagina = $this->calcularPagina($pos, false);
                        
                        $this->hechosDemanda[] = [
                            'texto' => $hecho,
                            'ubicacion' => "Pág. " . $pagina,
                            'posicion' => $pos,
                            'palabras_clave' => $this->extraerPalabrasClave($hecho)
                        ];
                    }
                }
            }
        }
        
        if (empty($this->hechosDemanda)) {
            $lineas = explode("\n", $this->textoDemanda);
            foreach ($lineas as $linea) {
                $linea = trim($linea);
                if (strlen($linea) > 50 && !preg_match('/^(?:===|PÁGINA|EXPEDIENTE|JUZGADO)/', $linea)) {
                    $this->hechosDemanda[] = [
                        'texto' => substr($linea, 0, 200),
                        'ubicacion' => "Documento",
                        'posicion' => 0,
                        'palabras_clave' => $this->extraerPalabrasClave($linea)
                    ];
                    break;
                }
            }
        }
    }
    
    private function extraerRespuestasContestacion() {
        if (empty($this->textoContestacion)) return;
        
        foreach ($this->hechosDemanda as $index => $hecho) {
            $respuesta = $this->buscarRespuestaParaHecho($hecho);
            $this->respuestasContestacion[$index] = $respuesta;
        }
    }
    
    private function buscarRespuestaParaHecho($hecho) {
        $mejorRespuesta = [
            'texto' => 'No se identifica respuesta específica',
            'ubicacion' => 'No identificable',
            'coincidencia' => 0
        ];
        
        $palabrasClave = $hecho['palabras_clave'];
        if (empty($palabrasClave)) return $mejorRespuesta;
        
        $lineas = explode("\n", $this->textoContestacion);
        $mejorCoincidencia = 0;
        
        foreach ($lineas as $linea) {
            if (strlen(trim($linea)) < 30) continue;
            
            $puntuacion = 0;
            foreach ($palabrasClave as $palabra) {
                if (stripos($linea, $palabra) !== false) {
                    $puntuacion += strlen($palabra);
                }
            }
            
            if (stripos($linea, 'niega') !== false || 
                stripos($linea, 'acepta') !== false ||
                stripos($linea, 'controvierte') !== false) {
                $puntuacion *= 1.5;
            }
            
            if ($puntuacion > $mejorCoincidencia) {
                $mejorCoincidencia = $puntuacion;
                $pos = strpos($this->textoContestacion, substr($linea, 0, 50));
                $pagina = $this->calcularPagina($pos, true);
                
                $mejorRespuesta = [
                    'texto' => trim(substr($linea, 0, 300)) . (strlen($linea) > 300 ? '...' : ''),
                    'ubicacion' => "Pág. " . $pagina,
                    'coincidencia' => $mejorCoincidencia
                ];
            }
        }
        
        return $mejorRespuesta;
    }
    
    private function extraerPalabrasClave($texto) {
        $palabras = str_word_count(strtolower($texto), 1, 'áéíóúüñ');
        $excluidas = ['para', 'con', 'por', 'del', 'las', 'los', 'una', 'como', 
                      'este', 'esta', 'dicho', 'dicha', 'sobre', 'entre'];
        
        $claves = [];
        foreach ($palabras as $palabra) {
            if (strlen($palabra) > 4 && !in_array($palabra, $excluidas)) {
                $claves[] = $palabra;
            }
        }
        
        return array_slice(array_unique($claves), 0, 8);
    }
    
    private function calcularPagina($posicion, $esContestacion = false) {
        $texto = $esContestacion ? $this->textoContestacion : $this->textoDemanda;
        $paginas = explode("=== PÁGINA ", $texto);
        $acumulado = 0;
        
        foreach ($paginas as $index => $pagina) {
            if ($index == 0) continue;
            $acumulado += strlen($pagina);
            if ($posicion < $acumulado) {
                return $index;
            }
        }
        
        return 1;
    }
    
    private function generarBloqueInformativo() {
        $partes = $this->extraerPartes();
        $juzgado = $this->extraerJuzgado();
        $expediente = $this->extraerExpediente();
        
        $bloque = "\n" . str_repeat("═", 120) . "\n";
        $bloque .= "                     **⚖️ MODO DEMANDA-CONTESTACIÓN - ANÁLISIS COMPARATIVO**\n";
        $bloque .= str_repeat("═", 120) . "\n\n";
        
        $bloque .= "**📋 BLOQUE INFORMATIVO**\n";
        $bloque .= str_repeat("─", 120) . "\n";
        $bloque .= "| Campo | Valor |\n";
        $bloque .= "|-------|-------|\n";
        $bloque .= "| **PARTES** | {$partes} |\n";
        $bloque .= "| **JUZGADO** | {$juzgado} |\n";
        $bloque .= "| **EXPEDIENTE** | {$expediente} |\n\n";
        
        return $bloque;
    }
    
    private function extraerPartes() {
        $patrones = [
            '/(?:ACTOR|PARTE ACTORA|DEMANDANTE|QUEJOSO)[\s:]+([^\\n]+).*?(?:DEMANDADO|PARTE DEMANDADA)[\s:]+([^\\n]+)/is',
            '/C\.\s*([^\\n]+?)\s+VS?\s+([^\\n]+)/i',
            '/([^\\n]+?)\s+(?:CONTRA|VS?\.?)\s+([^\\n]+)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                if (count($matches) >= 3) {
                    return trim($matches[1]) . " VS " . trim($matches[2]);
                }
            }
        }
        
        return "No identificable";
    }
    
    private function extraerJuzgado() {
        $patrones = [
            '/(?:JUZGADO|Juzgado|JUECES|JUEZ)[\s:]+([^\\n]+(?:[^\\n]+){0,2})/i',
            '/(?:PRIMERO|SEGUNDO|TERCERO|CUARTO|QUINTO)\s+(?:DE LO CIVIL|CIVIL|FAMILIAR)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                return trim($matches[0]);
            }
        }
        
        return "No identificable";
    }
    
    private function extraerExpediente() {
        $patrones = [
            '/EXPEDIENTE[\s:]+([^\s]+(?:\s*[\/-]\s*[^\s]+)*)/i',
            '/(?:N[°º]\s*)?(\d+[-\/]\d+(?:[-\/]\d+)?)/',
            '/(?:EXP\.?\s*)?(\d+\s*[\/-]\s*\d+(?:\s*[\/-]\s*\d+)?)/i'
        ];
        
        foreach ($patrones as $patron) {
            if (preg_match($patron, $this->textoCompleto, $matches)) {
                return trim($matches[1] ?? $matches[0]);
            }
        }
        
        return "No identificable";
    }
    
    private function generarTablaComparativa() {
        if (empty($this->hechosDemanda)) {
            return "**⚠️ No se identificaron hechos en la demanda para comparar.**\n\n";
        }
        
        $tabla = "\n**📊 TABLA COMPARATIVA ÚNICA**\n";
        $tabla .= str_repeat("─", 120) . "\n\n";
        $tabla .= "| Nº | Hecho o prestación (Demanda) | Ubicación en Demanda | Respuesta correspondiente (Contestación) | Ubicación en Contestación | Observaciones |\n";
        $tabla .= "|----|------------------------------|----------------------|----------------------------------------|---------------------------|---------------|\n";
        
        $contador = 1;
        foreach ($this->hechosDemanda as $index => $hecho) {
            $respuesta = $this->respuestasContestacion[$index] ?? [
                'texto' => 'No se identifica respuesta específica',
                'ubicacion' => 'No identificable'
            ];
            
            $hechoTexto = str_replace(["\n", "\r"], " ", $hecho['texto']);
            $hechoTexto = substr($hechoTexto, 0, 100) . (strlen($hechoTexto) > 100 ? '...' : '');
            
            $respuestaTexto = str_replace(["\n", "\r"], " ", $respuesta['texto']);
            $respuestaTexto = substr($respuestaTexto, 0, 100) . (strlen($respuestaTexto) > 100 ? '...' : '');
            
            $tabla .= sprintf("| %d | %s | %s | %s | %s | |\n",
                $contador,
                $hechoTexto,
                $hecho['ubicacion'],
                $respuestaTexto,
                $respuesta['ubicacion']
            );
            
            $contador++;
        }
        
        $tabla .= "\n";
        return $tabla;
    }
    
    private function generarBloqueFinal() {
        $bloque = "\n" . str_repeat("═", 120) . "\n";
        $bloque .= "**⚠️ BLOQUE FINAL - LIMITACIONES DEL ANÁLISIS**\n";
        $bloque .= str_repeat("═", 120) . "\n";
        $bloque .= "Mextopo es un asistente de inteligencia artificial utilizado como\n";
        $bloque .= "herramienta de apoyo. El contenido generado puede contener errores\n";
        $bloque .= "u omisiones. La revisión final y la responsabilidad del dictamen\n";
        $bloque .= "corresponden exclusivamente al perito firmante.\n";
        $bloque .= str_repeat("═", 120) . "\n";
        
        return $bloque;
    }
}
?>