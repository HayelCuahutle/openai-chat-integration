<?php
/**
 * Funciones para redención de cupones (segundo paso)
 * Solo se ejecuta cuando realmente se aplica el descuento
 * VERSIÓN CORREGIDA - Compatible con estructura actual de tablas
 */

/**
 * Redimir cupón (aplicar descuento) - Paso final - VERSIÓN CORREGIDA
 */
function redimirCupon($pdo, $cupon_asignado_id, $redimido_por = 'cajero', $notas = '') {
    try {
        // Iniciar transacción para evitar race conditions
        $pdo->beginTransaction();
        
        // 1. Verificar que el cupón existe y está en estado válido
        $stmt_check = $pdo->prepare("
            SELECT 
                ca.*,
                cp.codigo as cupon_codigo,
                cp.descripcion,
                cp.descuento_tipo,
                cp.descuento_valor,
                cp.uso_maximo,
                cp.usos_actuales,
                -- Verificar si ya fue redimido
                (SELECT COUNT(*) FROM cupones_redenciones WHERE cupon_asignado_id = ca.id) as ya_redimido
            FROM cupones_asignados ca
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE ca.id = ? 
            FOR UPDATE  -- Bloquea el registro para esta transacción
        ");
        $stmt_check->execute([$cupon_asignado_id]);
        
        if ($stmt_check->rowCount() === 0) {
            throw new Exception("Cupón no encontrado (ID: $cupon_asignado_id)");
        }
        
        $cupon = $stmt_check->fetch(PDO::FETCH_ASSOC);
        
        // 2. Verificar si YA FUE REDIMIDO
        if ($cupon['ya_redimido'] > 0) {
            throw new Exception("Este cupón ya fue redimido anteriormente");
        }
        
        // 3. Verificar estado
        if ($cupon['estado'] === 'redimido') {
            throw new Exception("Cupón ya marcado como redimido");
        }
        
        if ($cupon['estado'] === 'expirado' || $cupon['estado'] === 'cancelado') {
            throw new Exception("Cupón no está disponible (estado: " . $cupon['estado'] . ")");
        }
        
        // 4. Verificar fecha de expiración
        $hoy = date('Y-m-d');
        if (!empty($cupon['fecha_fin']) && $cupon['fecha_fin'] < $hoy) {
            // Marcar como expirado
            $pdo->prepare("UPDATE cupones_asignados SET estado = 'expirado' WHERE id = ?")
                ->execute([$cupon_asignado_id]);
            throw new Exception("Cupón expirado (fecha límite: " . $cupon['fecha_fin'] . ")");
        }
        
        // 5. Verificar límite de usos del cupón promocional
        if ($cupon['uso_maximo'] > 0 && $cupon['usos_actuales'] >= $cupon['uso_maximo']) {
            throw new Exception("Este tipo de cupón ha alcanzado su límite máximo de usos");
        }
        
        // 6. REGISTRAR REDENCIÓN (paso final) - CONSULTA CORREGIDA
        // Usando la estructura EXACTA de tu tabla cupones_redenciones
        $stmt_redencion = $pdo->prepare("
            INSERT INTO cupones_redenciones 
            (cupon_asignado_id, redimido_por, monto_descuento, 
             ip_address, device_info, notas, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        
        // Calcular monto si es necesario (aquí puedes agregar lógica de cálculo)
        $monto_descuento = 0.00; // Por defecto
        
        $stmt_redencion->execute([
            $cupon_asignado_id,
            $redimido_por,
            $monto_descuento,
            $_SERVER['REMOTE_ADDR'],
            substr($_SERVER['HTTP_USER_AGENT'], 0, 255),
            $notas
            // fecha_redencion se auto-llena con CURRENT_TIMESTAMP (columna timestamp)
            // created_at se llena con NOW()
        ]);
        
        $redencion_id = $pdo->lastInsertId();
        
        // 7. ACTUALIZAR ESTADO del cupón asignado
        $stmt_update_cupon = $pdo->prepare("
            UPDATE cupones_asignados 
            SET estado = 'redimido',
                redimido_por = ?,
                fecha_redimido = NOW(),
                qr_validated = 1,
                qr_validation_date = NOW()
            WHERE id = ?
        ");
        $stmt_update_cupon->execute([$redimido_por, $cupon_asignado_id]);
        
        // 8. INCREMENTAR contador de usos en cupón promocional
        $stmt_increment = $pdo->prepare("
            UPDATE cupones_promocionales 
            SET usos_actuales = usos_actuales + 1 
            WHERE id = ?
        ");
        $stmt_increment->execute([$cupon['cupon_id']]);
        
        // 9. Registrar escaneo de redención (diferente del de validación)
        // Usando la estructura EXACTA de tu tabla cupones_qr_scans
        $stmt_scan = $pdo->prepare("
            INSERT INTO cupones_qr_scans 
            (cupon_asignado_id, scan_type, scan_result, validated_by, 
             ip_address, device_info, created_at)
            VALUES (?, 'redemption_scan', 'success', ?, ?, ?, NOW())
        ");
        $stmt_scan->execute([
            $cupon_asignado_id,
            $redimido_por,
            $_SERVER['REMOTE_ADDR'],
            substr($_SERVER['HTTP_USER_AGENT'], 0, 255)
        ]);
        
        // 10. Confirmar transacción
        $pdo->commit();
        
        // Preparar respuesta exitosa
        $descuento_texto = $cupon['descuento_tipo'] == 'porcentaje' 
            ? $cupon['descuento_valor'] . '%' 
            : '$' . number_format($cupon['descuento_valor'], 2);
        
        return [
            'success' => true,
            'message' => '🎉 ¡CUPÓN REDIMIDO EXITOSAMENTE!',
            'code' => 'REDEEMED_SUCCESS',
            'redemption_id' => $redencion_id,
            'cupon' => [
                'id' => $cupon['id'],
                'codigo' => $cupon['cupon_codigo'],
                'usuario' => $cupon['usuario_nombre'],
                'descuento' => $descuento_texto,
                'descripcion' => $cupon['descripcion'],
                'fecha_redencion' => date('Y-m-d H:i:s'),
                'redimido_por' => $redimido_por
            ],
            'metadata' => [
                'timestamp' => date('Y-m-d H:i:s'),
                'action' => 'redimir',
                'notas' => 'Redención completada correctamente'
            ]
        ];
        
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        error_log("Error redimiendo cupón ID {$cupon_asignado_id}: " . $e->getMessage());
        
        return [
            'success' => false,
            'message' => '❌ Error al redimir cupón: ' . $e->getMessage(),
            'code' => 'REDEMPTION_ERROR',
            'error_details' => $e->getMessage()
        ];
    }
}

/**
 * Verificar si un cupón puede ser redimido
 */
function puedeRedimirCupon($pdo, $cupon_asignado_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT 
                ca.estado,
                ca.fecha_redimido,
                cp.fecha_fin,
                (SELECT COUNT(*) FROM cupones_redenciones WHERE cupon_asignado_id = ca.id) as ya_redimido
            FROM cupones_asignados ca
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE ca.id = ?
        ");
        $stmt->execute([$cupon_asignado_id]);
        
        if ($stmt->rowCount() === 0) {
            return [
                'puede_redimir' => false,
                'razon' => 'Cupón no encontrado'
            ];
        }
        
        $datos = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verificar si ya fue redimido
        if ($datos['ya_redimido'] > 0) {
            return [
                'puede_redimir' => false,
                'razon' => 'Ya redimido anteriormente'
            ];
        }
        
        // Verificar estado
        if ($datos['estado'] === 'redimido') {
            return [
                'puede_redimir' => false,
                'razon' => 'Ya redimido'
            ];
        }
        
        if ($datos['estado'] === 'expirado' || $datos['estado'] === 'cancelado') {
            return [
                'puede_redimir' => false,
                'razon' => 'Estado: ' . $datos['estado']
            ];
        }
        
        // Verificar fecha de expiración
        $hoy = date('Y-m-d');
        if (!empty($datos['fecha_fin']) && $datos['fecha_fin'] < $hoy) {
            return [
                'puede_redimir' => false,
                'razon' => 'Expirado (fecha límite: ' . $datos['fecha_fin'] . ')'
            ];
        }
        
        return [
            'puede_redimir' => true,
            'razon' => 'Cupón válido para redención'
        ];
        
    } catch (Exception $e) {
        error_log("Error verificando redención: " . $e->getMessage());
        return [
            'puede_redimir' => false,
            'razon' => 'Error del sistema'
        ];
    }
}

/**
 * Obtener historial de redenciones de un cupón
 */
function getHistorialRedenciones($pdo, $cupon_asignado_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM cupones_redenciones 
            WHERE cupon_asignado_id = ? 
            ORDER BY fecha_redencion DESC
        ");
        $stmt->execute([$cupon_asignado_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        error_log("Error obteniendo historial de redenciones: " . $e->getMessage());
        return [];
    }
}

/**
 * Obtener estadísticas de redenciones
 */
function getEstadisticasRedenciones($pdo, $fecha_inicio = null, $fecha_fin = null) {
    try {
        $where = "1=1";
        $params = [];
        
        if ($fecha_inicio) {
            $where .= " AND DATE(cr.fecha_redencion) >= ?";
            $params[] = $fecha_inicio;
        }
        
        if ($fecha_fin) {
            $where .= " AND DATE(cr.fecha_redencion) <= ?";
            $params[] = $fecha_fin;
        }
        
        $query = "
            SELECT 
                COUNT(*) as total_redenciones,
                COUNT(DISTINCT cr.cupon_asignado_id) as cupones_unicos,
                COUNT(DISTINCT ca.usuario_email) as usuarios_unicos,
                DATE(cr.fecha_redencion) as fecha,
                cp.codigo as tipo_cupon,
                cp.descuento_tipo,
                cp.descuento_valor
            FROM cupones_redenciones cr
            JOIN cupones_asignados ca ON cr.cupon_asignado_id = ca.id
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE $where
            GROUP BY DATE(cr.fecha_redencion), cp.id
            ORDER BY fecha DESC
            LIMIT 30
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log("Error obteniendo estadísticas: " . $e->getMessage());
        return [];
    }
}

/**
 * Función alternativa SIMPLIFICADA para redimir cupón
 * Si la función principal sigue dando problemas, usa esta
 */
function redimirCuponSimple($pdo, $cupon_asignado_id, $redimido_por = 'cajero', $notas = '') {
    try {
        $pdo->beginTransaction();
        
        // 1. Verificar cupón
        $stmt = $pdo->prepare("
            SELECT ca.*, cp.codigo as cupon_codigo 
            FROM cupones_asignados ca
            JOIN cupones_promocionales cp ON ca.cupon_id = cp.id
            WHERE ca.id = ? AND ca.estado = 'pendiente'
        ");
        $stmt->execute([$cupon_asignado_id]);
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("Cupón no encontrado o no está pendiente");
        }
        
        $cupon = $stmt->fetch();
        
        // 2. Insertar redención (versión ultra-simple)
        $stmt_red = $pdo->prepare("
            INSERT INTO cupones_redenciones 
            (cupon_asignado_id, redimido_por, ip_address, device_info, notas)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt_red->execute([
            $cupon_asignado_id,
            $redimido_por,
            $_SERVER['REMOTE_ADDR'],
            substr($_SERVER['HTTP_USER_AGENT'], 0, 255),
            $notas
        ]);
        
        $redencion_id = $pdo->lastInsertId();
        
        // 3. Actualizar cupón
        $pdo->prepare("UPDATE cupones_asignados SET estado = 'redimido', fecha_redimido = NOW() WHERE id = ?")
            ->execute([$cupon_asignado_id]);
        
        // 4. Registrar scan
        $pdo->prepare("
            INSERT INTO cupones_qr_scans 
            (cupon_asignado_id, scan_type, scan_result, validated_by, ip_address, device_info)
            VALUES (?, 'redemption_scan', 'success', ?, ?, ?)
        ")->execute([
            $cupon_asignado_id,
            $redimido_por,
            $_SERVER['REMOTE_ADDR'],
            substr($_SERVER['HTTP_USER_AGENT'], 0, 255)
        ]);
        
        $pdo->commit();
        
        return [
            'success' => true,
            'message' => '✅ Cupón redimido exitosamente',
            'redemption_id' => $redencion_id,
            'cupon' => $cupon
        ];
        
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return [
            'success' => false,
            'message' => 'Error: ' . $e->getMessage()
        ];
    }
}

/**
 * Verificar estructura de tablas (para debugging)
 */
function verificarEstructuraTablas($pdo) {
    $resultados = [];
    
    $tablas = [
        'cupones_redenciones' => [
            'columnas_esperadas' => ['id', 'cupon_asignado_id', 'redimido_por', 'monto_descuento', 'fecha_redencion', 'ip_address', 'device_info', 'notas', 'created_at']
        ],
        'cupones_qr_scans' => [
            'columnas_esperadas' => ['id', 'cupon_asignado_id', 'scan_type', 'scan_result', 'validated_by', 'ip_address', 'device_info', 'scan_timestamp', 'created_at']
        ]
    ];
    
    foreach ($tablas as $tabla => $info) {
        try {
            $stmt = $pdo->query("DESCRIBE $tabla");
            $columnas = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            $resultados[$tabla] = [
                'existe' => true,
                'columnas' => $columnas,
                'coincide' => count(array_diff($info['columnas_esperadas'], $columnas)) === 0
            ];
        } catch (Exception $e) {
            $resultados[$tabla] = [
                'existe' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    return $resultados;
}
?>